-- Scavenger Master — hunts, items, players, submissions, wheel spins.
-- Capability tokens (host/player) are stored as SHA-256 hashes only.

create table if not exists hunts (
  id text primary key,
  join_code text not null unique,
  host_token_hash text not null,
  title text not null,
  notes text not null default '',
  prize_pot text not null default '',
  gift_cards text not null default '[]',
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists hunt_items (
  id text primary key,
  hunt_id text not null references hunts (id) on delete cascade,
  sort_order integer not null,
  title text not null,
  hint text not null default '',
  points integer not null default 1
);

create index if not exists hunt_items_hunt_id_idx on hunt_items (hunt_id);

create table if not exists players (
  id text primary key,
  hunt_id text not null references hunts (id) on delete cascade,
  token_hash text not null,
  callsign text not null,
  gift_card_pick text not null default '',
  joined_at timestamptz not null default now()
);

create index if not exists players_hunt_id_idx on players (hunt_id);
create unique index if not exists players_hunt_callsign_idx
  on players (hunt_id, lower(callsign));

create table if not exists submissions (
  id text primary key,
  hunt_id text not null references hunts (id) on delete cascade,
  player_id text not null references players (id) on delete cascade,
  item_id text not null references hunt_items (id) on delete cascade,
  photo_data text not null,
  note text not null default '',
  status text not null default 'counted',
  created_at timestamptz not null default now()
);

create unique index if not exists submissions_player_item_idx
  on submissions (player_id, item_id);
create index if not exists submissions_hunt_id_idx on submissions (hunt_id);

create table if not exists wheel_spins (
  id text primary key,
  hunt_id text not null references hunts (id) on delete cascade,
  winner_player_id text not null references players (id) on delete cascade,
  pool text not null,
  rotation integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists wheel_spins_hunt_id_idx on wheel_spins (hunt_id);
