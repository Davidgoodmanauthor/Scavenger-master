alter table hunts add column if not exists admin_name text not null default '';
alter table hunts add column if not exists environment text not null default 'family';
alter table hunts add column if not exists pot_enabled boolean not null default false;
alter table hunts add column if not exists pot_per_player integer not null default 0;
alter table hunts add column if not exists pot_remaining integer not null default 0;
alter table hunts add column if not exists skip_ids text not null default '[]';

alter table players add column if not exists beat text not null default '';

alter table wheel_spins add column if not exists outcome text not null default 'pending';
