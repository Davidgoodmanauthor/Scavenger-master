-- Extra lists of finds. Opening list is 1. Each later release increments.
alter table hunt_items add column if not exists list_no integer not null default 1;
