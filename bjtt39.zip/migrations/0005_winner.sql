alter table hunts add column if not exists declared_winner_id text not null default '';
alter table wheel_spins add column if not exists landed_card text not null default '';
