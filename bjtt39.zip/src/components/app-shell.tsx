import { useEffect, useState, type ReactNode } from "react";
import { getLastHunt } from "@/lib/device";
import { Mark } from "./mark";

function HuntChip() {
  const [href, setHref] = useState<string | null>(null);
  const [code, setCode] = useState("");
  useEffect(() => {
    const last = getLastHunt();
    if (!last) return;
    setCode(last.code);
    setHref(last.role === "host" ? `/h/${last.code}/host` : `/h/${last.code}`);
  }, []);
  if (!href) return null;
  return (
    <a
      href={href}
      className="mr-1 inline-flex h-9 max-w-[9rem] items-center rounded-md bg-accent px-2.5 text-xs font-medium text-accent-fg no-underline"
    >
      Hunt {code}
    </a>
  );
}

export function AppShell({
  children,
  right,
}: {
  children: ReactNode;
  right?: ReactNode;
}) {
  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-30 border-b border-border/80 bg-bg/92 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-lg items-center justify-between gap-2 px-4">
          <a href="/" className="flex min-w-0 items-center gap-2 text-fg">
            <Mark className="size-6 shrink-0 text-accent" />
            <span className="truncate font-display text-[15px] font-medium tracking-[0.14em] uppercase">
              Scavenger Master
            </span>
          </a>
          <div className="flex shrink-0 items-center gap-1">
            <HuntChip />
            {right}
            <a
              href="#night"
              data-set-mode="night"
              className="sm-mode-chip"
              aria-label="Night mode"
            >
              Night
            </a>
            <a
              href="#day"
              data-set-mode="day"
              className="sm-mode-chip"
              aria-label="Day mode"
            >
              Day
            </a>
          </div>
        </div>
      </header>
      <div className="mx-auto w-full max-w-lg px-4 pb-24 pt-6">{children}</div>
    </div>
  );
}
