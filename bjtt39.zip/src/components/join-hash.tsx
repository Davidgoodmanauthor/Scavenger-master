import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { parseJoinHash, rememberSnapshot } from "@/lib/invite";

export function JoinHashListener() {
  const navigate = useNavigate();

  useEffect(() => {
    function handle() {
      const parsed = parseJoinHash();
      if (!parsed) return;
      if (parsed.snapshot) rememberSnapshot(parsed.snapshot);
      const path = window.location.pathname.replace(/\/$/, "") || "/";
      if (path === `/h/${parsed.code}` || path.startsWith(`/h/${parsed.code}/`)) return;
      void navigate({
        to: "/h/$code",
        params: { code: parsed.code },
        hash: window.location.hash.replace(/^#/, ""),
        replace: true,
      });
    }
    handle();
    window.addEventListener("hashchange", handle);
    return () => window.removeEventListener("hashchange", handle);
  }, [navigate]);

  return null;
}
