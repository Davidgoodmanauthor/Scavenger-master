import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className={cn("text-accent", className)}
    >
      <circle cx="24" cy="24" r="21.5" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="24" cy="24" r="6" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="M24 5.5v6.5M24 36v6.5M5.5 24h6.5M36 24h6.5"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <path
        d="M24 14.5 L26.2 22.2 L24 21.2 L21.8 22.2 Z"
        fill="currentColor"
      />
      <path
        d="M24 33.5 L21.8 25.8 L24 26.8 L26.2 25.8 Z"
        fill="currentColor"
        opacity="0.45"
      />
    </svg>
  );
}
