import { useRef, useState } from "react";
import { Camera, LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { compressPhoto } from "@/lib/photo";

export function PhotoField({
  preview,
  disabled,
  onPick,
}: {
  preview?: string;
  disabled?: boolean;
  onPick: (dataUrl: string) => Promise<void> | void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onFile(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const data = await compressPhoto(file);
      await onPick(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not use that photo.");
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div className="relative flex flex-col gap-2">
      <div className="pointer-events-none absolute h-0 w-0 overflow-hidden opacity-0">
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          capture="environment"
          tabIndex={-1}
          aria-hidden="true"
          disabled={disabled || busy}
          onChange={(e) => void onFile(e.target.files?.[0])}
        />
      </div>
      {preview ? (
        <button
          type="button"
          className="overflow-hidden rounded-md border border-border"
          onClick={() => inputRef.current?.click()}
          disabled={disabled || busy}
        >
          <img src={preview} alt="Your find" className="aspect-[4/3] w-full object-cover" />
        </button>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={disabled || busy}
          className="flex aspect-[4/3] w-full flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border bg-raised text-muted hover:text-fg"
        >
          {busy ? (
            <LoaderCircle className="size-5 animate-spin" />
          ) : (
            <Camera className="size-5" />
          )}
          <span className="text-sm">{busy ? "Compressing…" : "Take or choose a photo"}</span>
        </button>
      )}
      {preview ? (
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={disabled || busy}
          onClick={() => inputRef.current?.click()}
        >
          Replace photo
        </Button>
      ) : null}
      {error ? <p className="text-xs text-danger">{error}</p> : null}
    </div>
  );
}
