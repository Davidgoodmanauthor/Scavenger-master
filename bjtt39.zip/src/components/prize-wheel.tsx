import { useEffect, useMemo, useState } from "react";
import type { WheelSpin } from "@/lib/types";
import { cn } from "@/lib/utils";

const FILLS = [
  "var(--color-accent)",
  "color-mix(in oklab, var(--color-accent) 42%, var(--color-fg))",
  "var(--color-raised)",
  "color-mix(in oklab, var(--color-accent) 68%, var(--color-bg))",
  "var(--color-surface)",
  "color-mix(in oklab, var(--color-fg) 22%, var(--color-bg))",
];

function polar(cx: number, cy: number, r: number, deg: number) {
  const rad = (deg * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function slicePath(cx: number, cy: number, r: number, start: number, end: number) {
  const sweep = ((end - start) % 360 + 360) % 360;
  if (sweep < 0.5 || sweep > 359.5) {
    return `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx} ${cy + r} A ${r} ${r} 0 1 1 ${cx} ${cy - r} Z`;
  }
  const a = polar(cx, cy, r, start);
  const b = polar(cx, cy, r, end);
  const large = sweep > 180 ? 1 : 0;
  return `M ${cx} ${cy} L ${a.x} ${a.y} A ${r} ${r} 0 ${large} 1 ${b.x} ${b.y} Z`;
}

export function PrizeWheel({
  labels,
  spin,
  spinning,
}: {
  labels: string[];
  spin: WheelSpin | null;
  spinning: boolean;
}) {
  const [rotation, setRotation] = useState(0);
  const [armed, setArmed] = useState(false);

  const names = labels.filter((label) => label.trim().length > 0);
  const slice = names.length > 0 ? 360 / names.length : 360;

  const wedges = useMemo(
    () =>
      names.map((name, i) => {
        const start = -90 + i * slice;
        const end = -90 + (i + 1) * slice;
        const mid = start + slice / 2;
        const labelAt = polar(50, 50, names.length === 1 ? 0 : 31, mid);
        return { name, i, start, end, mid, labelAt };
      }),
    [names, slice],
  );

  useEffect(() => {
    if (!spin) return;
    setArmed(true);
    const id = requestAnimationFrame(() => setRotation(spin.rotation));
    return () => cancelAnimationFrame(id);
  }, [spin?.id, spin?.rotation]);

  return (
    <div className="relative mx-auto w-full max-w-sm">
      <div className="absolute top-0 left-1/2 z-20 -translate-x-1/2 -translate-y-1">
        <div className="h-0 w-0 border-x-[10px] border-t-[20px] border-x-transparent border-t-accent" />
      </div>
      <div
        className={cn(
          "relative aspect-square w-full overflow-hidden rounded-full",
          "shadow-[var(--shadow-soft)]",
        )}
      >
        <svg
          viewBox="0 0 100 100"
          className="size-full"
          style={{
            transform: `rotate(${armed ? rotation : 0}deg)`,
            transition:
              spinning || armed
                ? "transform 5.4s cubic-bezier(0.12, 0.7, 0.16, 1)"
                : "none",
          }}
        >
          <circle cx="50" cy="50" r="49" fill="var(--color-border)" />
          {wedges.length === 0 ? (
            <circle cx="50" cy="50" r="47.5" fill="var(--color-surface)" />
          ) : (
            wedges.map((wedge) => (
              <path
                key={`${wedge.name}-${wedge.i}`}
                d={slicePath(50, 50, 47.5, wedge.start, wedge.end)}
                fill={FILLS[wedge.i % FILLS.length]}
                stroke="var(--color-bg)"
                strokeWidth={names.length > 1 ? 0.8 : 0}
              />
            ))
          )}
          {wedges.map((wedge) => {
            if (names.length === 1) return null;
            const fill =
              wedge.i % FILLS.length === 0
                ? "var(--color-accent-fg)"
                : "var(--color-fg)";
            return (
              <text
                key={`label-${wedge.i}`}
                x={wedge.labelAt.x}
                y={wedge.labelAt.y}
                textAnchor="middle"
                dominantBaseline="middle"
                fill={fill}
                fontSize={names.length > 8 ? 3.2 : names.length > 5 ? 3.8 : 4.4}
                fontWeight="600"
                transform={`rotate(${wedge.mid + 90} ${wedge.labelAt.x} ${wedge.labelAt.y})`}
              >
                {wedge.name.length > 16 ? `${wedge.name.slice(0, 15)}…` : wedge.name}
              </text>
            );
          })}
        </svg>
        <div className="pointer-events-none absolute inset-[38%] rounded-full border border-border bg-bg shadow-[var(--shadow-soft)]" />
        <div className="pointer-events-none absolute inset-[46%] rounded-full bg-accent" />
      </div>
      {names.length === 0 ? (
        <p className="mt-3 text-center text-sm text-muted">
          Equal slices show here once players pick a gift card.
        </p>
      ) : null}
    </div>
  );
}
