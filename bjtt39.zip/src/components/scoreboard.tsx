import type { HuntBoard } from "@/lib/types";
import { cn } from "@/lib/utils";

export function Scoreboard({
  board,
  onCell,
}: {
  board: HuntBoard;
  onCell?: (playerId: string, itemId: string) => void;
}) {
  const ranked = [...board.players].sort(
    (a, b) => b.points - a.points || a.callsign.localeCompare(b.callsign),
  );

  if (ranked.length === 0) {
    return (
      <p className="text-sm text-muted">Nobody has joined yet. Share the invite.</p>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-border">
      <table className="w-full min-w-[480px] border-collapse text-sm">
        <thead>
          <tr className="bg-raised text-left text-xs uppercase tracking-wider text-muted">
            <th className="px-3 py-2 font-medium">Player</th>
            {board.items.map((item, i) => (
              <th key={item.id} className="px-2 py-2 text-center font-medium">
                {i + 1}
              </th>
            ))}
            <th className="px-3 py-2 text-right font-medium">Pts</th>
          </tr>
        </thead>
        <tbody>
          {ranked.map((player) => (
            <tr key={player.id} className="border-t border-border">
              <td className="px-3 py-2">
                <div className="font-medium">{player.callsign}</div>
                {player.giftCardPick ? (
                  <div className="text-xs text-accent">{player.giftCardPick}</div>
                ) : null}
                {player.beat ? <div className="text-xs text-muted">Beat {player.beat}</div> : null}
              </td>
              {board.items.map((item) => {
                const sub = board.submissions.find(
                  (s) => s.playerId === player.id && s.itemId === item.id,
                );
                const counted = sub?.status === "counted";
                const rejected = sub?.status === "rejected";
                const pending = sub?.status === "pending";
                return (
                  <td key={item.id} className="px-2 py-2 text-center">
                    <button
                      type="button"
                      disabled={!sub || !onCell}
                      onClick={() => sub && onCell?.(player.id, item.id)}
                      className={cn(
                        "mx-auto flex size-10 items-center justify-center rounded-md border text-[10px] font-semibold",
                        counted && "border-ok/40 bg-ok/15 text-ok",
                        rejected && "border-danger/40 bg-danger/10 text-danger",
                        pending && "border-accent bg-accent text-accent-fg",
                        !sub && "border-border bg-raised text-faint",
                        sub && onCell && "hover:ring-2 hover:ring-accent/30",
                      )}
                      aria-label={`${player.callsign} ${item.title}`}
                    >
                      {counted ? "OK" : rejected ? "NO" : pending ? "PIC" : ""}
                    </button>
                  </td>
                );
              })}
              <td className="px-3 py-2 text-right font-medium tabular-nums">{player.points}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
