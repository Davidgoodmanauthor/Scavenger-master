import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Badge({
  className,
  tone = "muted",
  ...props
}: HTMLAttributes<HTMLSpanElement> & {
  tone?: "muted" | "ok" | "warn" | "accent";
}) {
  const tones = {
    muted: "bg-raised text-muted border-border",
    ok: "bg-ok/15 text-ok border-ok/25",
    warn: "bg-warn/15 text-warn border-warn/25",
    accent: "bg-accent/15 text-accent border-accent/20",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wider",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
