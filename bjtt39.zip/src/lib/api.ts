import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { envById } from "./environments";
import { buildPlayerHtml } from "./player-html";
import { uploadPlayHtml } from "./play-link";
import type {
  EnvironmentId,
  HuntBoard,
  HuntItem,
  HuntStatus,
  HuntSummary,
  PlayerRow,
  SubmissionMeta,
  SubmissionStatus,
  WheelOutcome,
  WheelPool,
  WheelSpin,
  YourPhoto,
} from "./types";

const nameSchema = z
  .string()
  .trim()
  .min(2, "Enter your name.")
  .max(24, "Name is too long.")
  .regex(/^[\p{L}\p{N}][\p{L}\p{N}. '\-]*$/u, "Use letters, numbers, spaces, or a hyphen.");

const adminNameSchema = z
  .string()
  .trim()
  .max(24)
  .transform((value) => {
    const cleaned = value
      .replace(/[^\p{L}\p{N}. '\-]/gu, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 24);
    return cleaned.length >= 2 ? cleaned : "Admin";
  });

const envSchema = z.enum([
  "police",
  "fire",
  "office",
  "warehouse",
  "school",
  "family",
  "other",
]);

const itemDraftSchema = z.object({
  id: z.string().trim().min(1).max(80).optional(),
  title: z.string().trim().min(2).max(80),
  hint: z.string().trim().max(160).default(""),
  listNo: z.number().int().min(1).max(50).optional(),
});

const itemListSchema = z.array(itemDraftSchema).min(1).max(100);
const extraListSchema = z.array(itemDraftSchema).min(1).max(5);

const photoSchema = z
  .string()
  .min(20)
  .max(220_000, "Photo is too large.")
  .regex(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/);

function parseIds(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((x): x is string => typeof x === "string");
  } catch {
    return [];
  }
}

function asBool(v: unknown): boolean {
  return v === true || v === "t" || v === "true" || v === 1;
}

function asInt(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function asEnv(v: string): EnvironmentId {
  const ok = envSchema.safeParse(v);
  return ok.success ? ok.data : "family";
}

function asSubStatus(v: string): SubmissionStatus {
  if (v === "rejected") return "rejected";
  if (v === "pending") return "pending";
  return "counted";
}

function asOutcome(v: string): WheelOutcome {
  if (v === "accepted" || v === "donated" || v === "deducted") return v;
  return "pending";
}

type HuntRow = {
  id: string;
  join_code: string;
  host_token_hash: string;
  title: string;
  notes: string;
  admin_name: string;
  environment: string;
  pot_enabled: unknown;
  pot_per_player: unknown;
  pot_remaining: unknown;
  skip_ids: string;
  declared_winner_id: string;
  status: string;
  created_at: string;
};

type ItemRow = {
  id: string;
  hunt_id: string;
  sort_order: number;
  title: string;
  hint: string;
  points: number;
  list_no: number;
};

type PlayerDbRow = {
  id: string;
  hunt_id: string;
  token_hash: string;
  callsign: string;
  gift_card_pick: string;
  beat: string;
  joined_at: string;
};

type SubRow = {
  id: string;
  hunt_id: string;
  player_id: string;
  item_id: string;
  photo_data: string;
  note: string;
  status: string;
  created_at: string;
};

type SpinRow = {
  id: string;
  hunt_id: string;
  winner_player_id: string;
  pool: string;
  rotation: number;
  outcome: string;
  landed_card: string;
  created_at: string;
};

const HUNT_SELECT = `
  id, join_code, host_token_hash, title, notes,
  coalesce(admin_name,'') as admin_name,
  coalesce(environment,'family') as environment,
  coalesce(pot_enabled, false) as pot_enabled,
  coalesce(pot_per_player, 0) as pot_per_player,
  coalesce(pot_remaining, 0) as pot_remaining,
  coalesce(skip_ids,'[]') as skip_ids,
  coalesce(declared_winner_id,'') as declared_winner_id,
  status, created_at::text as created_at
`;

async function cryptoBits() {
  const { randomBytes, createHash, randomUUID, timingSafeEqual } = await import("node:crypto");
  return { randomBytes, createHash, randomUUID, timingSafeEqual };
}

async function newToken() {
  const { randomBytes } = await cryptoBits();
  return randomBytes(24).toString("base64url");
}

async function hashToken(token: string) {
  const { createHash } = await cryptoBits();
  return createHash("sha256").update(token).digest("hex");
}

async function hashesMatch(a: string, b: string) {
  const { timingSafeEqual } = await cryptoBits();
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

async function mintJoinCode() {
  const { randomBytes } = await cryptoBits();
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(6);
  let code = "";
  for (let i = 0; i < 6; i += 1) {
    code += alphabet[bytes[i]! % alphabet.length];
  }
  return code;
}

async function db() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function loadHuntByCode(code: string): Promise<HuntRow | null> {
  const sql = await db();
  const upper = code.toUpperCase();
  async function select() {
    return sql.query<HuntRow>(
      `select ${HUNT_SELECT} from hunts where join_code = $1 limit 1`,
      [upper],
    );
  }
  let rows: HuntRow[] = [];
  try {
    rows = await select();
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (!/declared_winner_id|landed_card/i.test(msg)) throw err;
    await sql.query(
      "alter table hunts add column if not exists declared_winner_id text not null default ''",
    );
    await sql.query(
      "alter table wheel_spins add column if not exists landed_card text not null default ''",
    );
    rows = await select();
  }
  if (rows[0]) return rows[0];
  const { restoreHuntDump } = await import("@/lib/hunt-dump");
  const restored = await restoreHuntDump(upper);
  if (!restored) return null;
  const again = await select();
  return again[0] ?? null;
}

function toSummary(hunt: HuntRow, itemCount: number, playerCount: number): HuntSummary {
  return {
    id: hunt.id,
    joinCode: hunt.join_code,
    title: hunt.title,
    adminName: hunt.admin_name,
    environment: asEnv(hunt.environment),
    notes: hunt.notes,
    potEnabled: asBool(hunt.pot_enabled),
    potPerPlayer: asInt(hunt.pot_per_player),
    potRemaining: asInt(hunt.pot_remaining),
    playerCount,
    itemCount,
    status: hunt.status === "closed" ? "closed" : "open",
    declaredWinnerId: hunt.declared_winner_id ?? "",
    createdAt: hunt.created_at,
  };
}

function toItem(row: ItemRow): HuntItem {
  return {
    id: row.id,
    sortOrder: row.sort_order,
    listNo: Math.max(1, asInt(row.list_no) || 1),
    title: row.title,
    hint: row.hint,
    points: row.points,
  };
}

async function assembleBoard(
  hunt: HuntRow,
  role: HuntBoard["role"],
  you: HuntBoard["you"],
  yourPhotos: YourPhoto[],
): Promise<HuntBoard> {
  const sql = await db();
  const items = await sql<ItemRow>`
    select id, hunt_id, sort_order, title, hint, points,
           coalesce(list_no, 1) as list_no
    from hunt_items
    where hunt_id = ${hunt.id}
    order by sort_order asc
  `;
  const playerRows = await sql<PlayerDbRow>`
    select id, hunt_id, token_hash, callsign, gift_card_pick,
           coalesce(beat,'') as beat, joined_at::text as joined_at
    from players
    where hunt_id = ${hunt.id}
    order by joined_at asc
  `;
  const subs = await sql<SubRow>`
    select id, hunt_id, player_id, item_id, '' as photo_data, note, status,
           created_at::text as created_at
    from submissions
    where hunt_id = ${hunt.id}
  `;
  const spins = await sql<SpinRow>`
    select id, hunt_id, winner_player_id, pool, rotation,
           coalesce(outcome,'pending') as outcome,
           coalesce(landed_card,'') as landed_card,
           created_at::text as created_at
    from wheel_spins
    where hunt_id = ${hunt.id}
    order by created_at desc
    limit 1
  `;

  const players: PlayerRow[] = playerRows.map((p) => {
    const mine = subs.filter((s) => s.player_id === p.id);
    const counted = mine.filter((s) => s.status === "counted");
    const pending = mine.filter((s) => s.status === "pending");
    const points = counted.reduce((sum, s) => {
      const item = items.find((it) => it.id === s.item_id);
      return sum + (item?.points ?? 1);
    }, 0);
    return {
      id: p.id,
      callsign: p.callsign,
      giftCardPick: p.gift_card_pick,
      beat: p.beat,
      joinedAt: p.joined_at,
      completed: counted.length,
      pending: pending.length,
      points,
    };
  });

  const submissions: SubmissionMeta[] = subs.map((s) => ({
    id: s.id,
    playerId: s.player_id,
    itemId: s.item_id,
    note: s.note,
    status: asSubStatus(s.status),
    createdAt: s.created_at,
  }));

  let latestSpin: WheelSpin | null = null;
  const spin = spins[0];
  if (spin) {
    const winner = playerRows.find((p) => p.id === spin.winner_player_id);
    latestSpin = {
      id: spin.id,
      winnerPlayerId: spin.winner_player_id,
      winnerCallsign: winner?.callsign ?? "Unknown",
      landedGiftCard: spin.landed_card || winner?.gift_card_pick || "",
      pool: spin.pool === "complete" ? "complete" : "all",
      rotation: spin.rotation,
      outcome: asOutcome(spin.outcome),
      createdAt: spin.created_at,
    };
  }

  try {
    const { persistHuntDump } = await import("@/lib/hunt-dump");
    await persistHuntDump(hunt.id, hunt.join_code);
  } catch {
    // preview dump is best-effort
  }

  return {
    hunt: toSummary(hunt, items.length, playerRows.length),
    items: items.map(toItem),
    players,
    submissions,
    yourPhotos,
    latestSpin,
    role,
    you,
  };
}

async function requireHost(code: string, hostToken: string): Promise<HuntRow> {
  const hunt = await loadHuntByCode(code);
  if (!hunt) throw new Error("No hunt with that code.");
  const hash = await hashToken(hostToken);
  if (!(await hashesMatch(hash, hunt.host_token_hash))) {
    throw new Error("That host key does not match this hunt.");
  }
  return hunt;
}

async function requirePlayer(huntId: string, playerToken: string): Promise<PlayerDbRow> {
  const sql = await db();
  const hash = await hashToken(playerToken);
  const rows = await sql<PlayerDbRow>`
    select id, hunt_id, token_hash, callsign, gift_card_pick,
           coalesce(beat,'') as beat, joined_at::text as joined_at
    from players
    where hunt_id = ${huntId} and token_hash = ${hash}
    limit 1
  `;
  const player = rows[0];
  if (!player) throw new Error("Player key is not valid for this hunt.");
  return player;
}

async function upsertItems(
  huntId: string,
  drafts: {
    id?: string;
    title: string;
    hint?: string;
    listNo?: number;
  }[],
) {
  const sql = await db();
  const { randomUUID } = await cryptoBits();
  const existing = await sql<{ id: string; sort_order: number; list_no: number }>`
    select id, sort_order, coalesce(list_no, 1) as list_no
    from hunt_items
    where hunt_id = ${huntId}
  `;
  const have = new Set(existing.map((row) => row.id));
  let sort = existing.reduce((max, row) => Math.max(max, row.sort_order), -1);
  for (let i = 0; i < drafts.length; i += 1) {
    const item = drafts[i]!;
    if (item.id && have.has(item.id)) continue;
    sort += 1;
    const listNo =
      item.listNo && item.listNo >= 1 ? item.listNo : Math.floor(sort / 5) + 1;
    const itemId = item.id && item.id.length >= 4 ? item.id : randomUUID();
    await sql.query(
      `insert into hunt_items (id, hunt_id, sort_order, title, hint, points, list_no)
       values ($1,$2,$3,$4,$5,1,$6)
       on conflict (id) do nothing`,
      [itemId, huntId, sort, item.title, item.hint ?? "", listNo],
    );
  }
}

export const createHunt = createServerFn({ method: "POST" })
  .validator(
    z.object({
      adminName: adminNameSchema,
      environment: envSchema,
      potEnabled: z.boolean(),
      potPerPlayer: z.number().int().min(0).max(10000),
      items: itemListSchema,
    }),
  )
  .handler(async ({ data }) => {
    const env = envById(data.environment);
    const { randomUUID } = await cryptoBits();
    const sql = await db();
    const hostToken = await newToken();
    const hostHash = await hashToken(hostToken);
    const huntId = randomUUID();
    const title = env.name;
    const potPer = data.potEnabled ? data.potPerPlayer : 0;

    let joinCode = "";
    for (let attempt = 0; attempt < 8; attempt += 1) {
      joinCode = await mintJoinCode();
      try {
        await sql.query(
          `insert into hunts (
             id, join_code, host_token_hash, title, notes, admin_name, environment,
             pot_enabled, pot_per_player, pot_remaining, skip_ids, gift_cards, prize_pot, status
           ) values ($1,$2,$3,$4,'',$5,$6,$7,$8,0,'[]','[]','','open')`,
          [
            huntId,
            joinCode,
            hostHash,
            title,
            data.adminName,
            data.environment,
            data.potEnabled,
            potPer,
          ],
        );
        break;
      } catch (err) {
        if (attempt === 7) throw err;
      }
    }

    for (let i = 0; i < data.items.length; i += 1) {
      const item = data.items[i]!;
      await sql.query(
        `insert into hunt_items (id, hunt_id, sort_order, title, hint, points, list_no)
         values ($1,$2,$3,$4,$5,1,$6)`,
        [randomUUID(), huntId, i, item.title, item.hint ?? "", Math.floor(i / 5) + 1],
      );
    }

    const hunt = await loadHuntByCode(joinCode);
    if (!hunt) throw new Error("Hunt was created but could not be reloaded.");
    const board = await assembleBoard(hunt, "host", null, []);
    return { hostToken, joinCode, board };
  });

export const hydrateHunt = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z
        .string()
        .trim()
        .min(4)
        .max(8)
        .transform((value) => value.toUpperCase()),
      environment: envSchema,
      adminName: z.string().trim().min(1).max(24),
      potEnabled: z.boolean(),
      potPerPlayer: z.number().int().min(0).max(10000),
      items: itemListSchema,
      hostToken: z.string().min(8).optional(),
      playerToken: z.string().min(8).optional(),
      callsign: z.string().trim().min(2).max(24).optional(),
      giftCard: z.string().trim().max(40).optional(),
      beat: z.string().trim().max(24).optional(),
      status: z.enum(["open", "closed"]).optional(),
      potRemaining: z.number().int().min(0).max(100000).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const sql = await db();
    const { randomUUID } = await cryptoBits();
    let hunt = await loadHuntByCode(data.code);

    if (!hunt) {
      const env = envById(data.environment);
      const hostToken = data.hostToken || (await newToken());
      const hostHash = await hashToken(hostToken);
      const huntId = randomUUID();
      const adminName = data.adminName.replace(/[^\w. '\-]/gu, "").slice(0, 24) || "Admin";
      const potPer = data.potEnabled ? data.potPerPlayer : 0;
      const potRemaining = data.potEnabled
        ? Math.max(0, data.potRemaining ?? 0)
        : 0;
      const status = data.status === "closed" ? "closed" : "open";
      try {
        await sql.query(
          `insert into hunts (
             id, join_code, host_token_hash, title, notes, admin_name, environment,
             pot_enabled, pot_per_player, pot_remaining, skip_ids, gift_cards, prize_pot, status
           ) values ($1,$2,$3,$4,'',$5,$6,$7,$8,$9,'[]','[]','',$10)`,
          [
            huntId,
            data.code,
            hostHash,
            env.name,
            adminName,
            data.environment,
            data.potEnabled,
            potPer,
            potRemaining,
            status,
          ],
        );
      } catch {
        hunt = await loadHuntByCode(data.code);
      }
      if (!hunt) {
        await upsertItems(huntId, data.items);
        hunt = await loadHuntByCode(data.code);
      }
    }

    if (!hunt) throw new Error("Could not open that hunt on this phone.");

    await upsertItems(hunt.id, data.items);

    if (data.hostToken) {
      const hash = await hashToken(data.hostToken);
      if (!(await hashesMatch(hash, hunt.host_token_hash))) {
        await sql`update hunts set host_token_hash = ${hash} where id = ${hunt.id}`;
        hunt = { ...hunt, host_token_hash: hash };
      }
    }

    if (data.playerToken && data.callsign) {
      const tokenHash = await hashToken(data.playerToken);
      const known = await sql<PlayerDbRow>`
        select id, hunt_id, token_hash, callsign, gift_card_pick,
               coalesce(beat,'') as beat, joined_at::text as joined_at
        from players
        where hunt_id = ${hunt.id} and token_hash = ${tokenHash}
        limit 1
      `;
      if (!known[0]) {
        try {
          await sql.query(
            `insert into players (id, hunt_id, token_hash, callsign, gift_card_pick, beat)
             values ($1,$2,$3,$4,$5,$6)`,
            [
              randomUUID(),
              hunt.id,
              tokenHash,
              data.callsign,
              data.giftCard ?? "",
              asEnv(hunt.environment) === "police" ? (data.beat ?? "") : "",
            ],
          );
        } catch {
          // name already on this hunt
        }
      }
    }

    return assembleBoard(hunt, "guest", null, []);
  });

export const ensureHostHunt = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z
        .string()
        .trim()
        .min(4)
        .max(8)
        .transform((value) => value.toUpperCase()),
      hostToken: z.string().min(8).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { randomUUID } = await cryptoBits();
    const sql = await db();
    let hunt = await loadHuntByCode(data.code);
    const hostToken = data.hostToken || (await newToken());
    const hostHash = await hashToken(hostToken);
    if (hunt) {
      if (data.hostToken) {
        const hash = await hashToken(data.hostToken);
        if (await hashesMatch(hash, hunt.host_token_hash)) {
          return { hostToken: data.hostToken, joinCode: data.code, created: false as const };
        }
      }
      await sql`update hunts set host_token_hash = ${hostHash} where id = ${hunt.id}`;
      return { hostToken, joinCode: data.code, created: false as const };
    }
    const huntId = randomUUID();
    await sql.query(
      `insert into hunts (
         id, join_code, host_token_hash, title, notes, admin_name, environment,
         pot_enabled, pot_per_player, pot_remaining, skip_ids, gift_cards, prize_pot, status
       ) values ($1,$2,$3,$4,'',$5,$6,$7,$8,0,'[]','[]','','open')`,
      [huntId, data.code, hostHash, "Hunt", "Admin", "family", false, 0],
    );
    const env = envById("family");
    await upsertItems(
      huntId,
      env.items.slice(0, 5).map((item) => ({ title: item.title, hint: item.hint ?? "" })),
    );
    return { hostToken, joinCode: data.code, created: true as const };
  });

export const getBoard = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().optional(),
      playerToken: z.string().optional(),
    }),
  )
  .handler(async ({ data }): Promise<HuntBoard> => {
    const hunt = await loadHuntByCode(data.code);
    if (!hunt) throw new Error("No hunt with that code.");

    if (data.hostToken) {
      const hash = await hashToken(data.hostToken);
      if (await hashesMatch(hash, hunt.host_token_hash)) {
        return assembleBoard(hunt, "host", null, []);
      }
    }

    if (data.playerToken) {
      try {
        const player = await requirePlayer(hunt.id, data.playerToken);
        const sql = await db();
        const photos = await sql<SubRow>`
          select id, hunt_id, player_id, item_id, photo_data, note, status,
                 created_at::text as created_at
          from submissions
          where player_id = ${player.id}
        `;
        const yourPhotos: YourPhoto[] = photos.map((p) => ({
          itemId: p.item_id,
          submissionId: p.id,
          photoData: p.photo_data,
          note: p.note,
          status: asSubStatus(p.status),
        }));
        return assembleBoard(
          hunt,
          "player",
          {
            playerId: player.id,
            callsign: player.callsign,
            giftCardPick: player.gift_card_pick,
            beat: player.beat,
          },
          yourPhotos,
        );
      } catch {
        // stale player key
      }
    }

    return assembleBoard(hunt, "guest", null, []);
  });

export const joinHunt = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      callsign: nameSchema,
      giftCard: z.string().trim().max(40).default(""),
      beat: z.string().trim().max(24).default(""),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await loadHuntByCode(data.code);
    if (!hunt) throw new Error("No hunt with that code.");
    if (hunt.status === "closed") throw new Error("This hunt is closed.");
    const potOn = asBool(hunt.pot_enabled);
    const giftCard = data.giftCard.trim().slice(0, 40);
    if (potOn && giftCard.length < 2) {
      throw new Error("Pick the gift card you want if you win.");
    }

    const sql = await db();
    const { randomUUID } = await cryptoBits();
    const playerToken = await newToken();
    const tokenHash = await hashToken(playerToken);
    const playerId = randomUUID();
    const callsign = data.callsign.trim();
    const beat = asEnv(hunt.environment) === "police" ? data.beat.trim() : "";

    try {
      await sql.query(
        `insert into players (id, hunt_id, token_hash, callsign, gift_card_pick, beat)
         values ($1,$2,$3,$4,$5,$6)`,
        [playerId, hunt.id, tokenHash, callsign, potOn ? giftCard : "", beat],
      );
    } catch {
      throw new Error("That name is already on this hunt. Pick another.");
    }

    if (potOn) {
      const add = asInt(hunt.pot_per_player);
      await sql`
        update hunts set pot_remaining = pot_remaining + ${add}
        where id = ${hunt.id}
      `;
    }

    return { playerToken, playerId, callsign, joinCode: hunt.join_code };
  });

export const submitPhoto = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      playerToken: z.string().min(8),
      itemId: z.string().min(8),
      photoData: photoSchema,
      note: z.string().trim().max(140).default(""),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await loadHuntByCode(data.code);
    if (!hunt) throw new Error("No hunt with that code.");
    if (hunt.status === "closed") throw new Error("This hunt is closed.");
    const player = await requirePlayer(hunt.id, data.playerToken);
    const sql = await db();
    const items = await sql<ItemRow>`
      select id, hunt_id, sort_order, title, hint, points
      from hunt_items
      where id = ${data.itemId} and hunt_id = ${hunt.id}
      limit 1
    `;
    if (!items[0]) throw new Error("That find is not on this hunt.");
    const { randomUUID } = await cryptoBits();
    await sql.query(
      `insert into submissions (id, hunt_id, player_id, item_id, photo_data, note, status)
       values ($1,$2,$3,$4,$5,$6,'pending')
       on conflict (player_id, item_id)
       do update set photo_data = excluded.photo_data, note = excluded.note,
                     status = 'pending', created_at = now()`,
      [randomUUID(), hunt.id, player.id, data.itemId, data.photoData, data.note],
    );
    return { ok: true as const };
  });

export const pickGiftCard = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      playerToken: z.string().min(8),
      giftCard: z.string().trim().max(40),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await loadHuntByCode(data.code);
    if (!hunt) throw new Error("No hunt with that code.");
    const player = await requirePlayer(hunt.id, data.playerToken);
    if (!asBool(hunt.pot_enabled)) throw new Error("This hunt has no pot.");
    if (data.giftCard.trim().length < 2) throw new Error("Type the gift card you want.");
    const sql = await db();
    await sql`
      update players set gift_card_pick = ${data.giftCard}
      where id = ${player.id}
    `;
    return { ok: true as const };
  });

export const declareWinner = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      playerId: z.string().min(8),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    const sql = await db();
    const rows = await sql<{ id: string }>`
      select id from players where id = ${data.playerId} and hunt_id = ${hunt.id} limit 1
    `;
    if (!rows[0]) throw new Error("That player is not on this hunt.");
    await sql`update hunts set declared_winner_id = ${data.playerId} where id = ${hunt.id}`;
    return { ok: true as const };
  });

async function upsertGuestPlayer(
  hunt: HuntRow,
  input: { callsign: string; giftCard: string; beat: string },
): Promise<string> {
  const sql = await db();
  const existing = await sql<PlayerDbRow>`
    select id, hunt_id, token_hash, callsign, gift_card_pick,
           coalesce(beat,'') as beat, joined_at::text as joined_at
    from players
    where hunt_id = ${hunt.id} and lower(callsign) = ${input.callsign.toLowerCase()}
    limit 1
  `;
  if (existing[0]) {
    if (input.giftCard) {
      await sql`
        update players set gift_card_pick = ${input.giftCard} where id = ${existing[0].id}
      `;
    }
    if (input.beat && asEnv(hunt.environment) === "police") {
      await sql`update players set beat = ${input.beat} where id = ${existing[0].id}`;
    }
    return existing[0].id;
  }
  const { randomUUID } = await cryptoBits();
  const tokenHash = await hashToken(await newToken());
  const playerId = randomUUID();
  await sql.query(
    `insert into players (id, hunt_id, token_hash, callsign, gift_card_pick, beat)
     values ($1,$2,$3,$4,$5,$6)`,
    [
      playerId,
      hunt.id,
      tokenHash,
      input.callsign.trim(),
      input.giftCard,
      asEnv(hunt.environment) === "police" ? input.beat : "",
    ],
  );
  if (asBool(hunt.pot_enabled) && asInt(hunt.pot_per_player) > 0) {
    await sql`
      update hunts set pot_remaining = pot_remaining + ${asInt(hunt.pot_per_player)}
      where id = ${hunt.id}
    `;
  }
  return playerId;
}

export const registerGuestPlayer = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      callsign: nameSchema,
      giftCard: z.string().trim().max(40).default(""),
      beat: z.string().trim().max(24).default(""),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    await upsertGuestPlayer(hunt, {
      callsign: data.callsign,
      giftCard: data.giftCard,
      beat: data.beat,
    });
    return { ok: true as const };
  });

export const receiveGuestStill = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      callsign: nameSchema,
      giftCard: z.string().trim().max(40).default(""),
      beat: z.string().trim().max(24).default(""),
      itemIndex: z.number().int().min(0).max(99),
      inBeat: z.enum(["in", "out", ""]).default(""),
      photoUrl: z.string().url().max(800),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    let parsed: URL;
    try {
      parsed = new URL(data.photoUrl);
    } catch {
      throw new Error("Bad still.");
    }
    const host = parsed.hostname.toLowerCase();
    const allowed =
      host === "ntfy.sh" ||
      host.endsWith(".ntfy.sh") ||
      host.endsWith("catbox.moe") ||
      host === "filebin.net" ||
      host.endsWith(".filebin.net");
    if (parsed.protocol !== "https:" || !allowed) {
      throw new Error("Bad still.");
    }
    const photoRes = await fetch(parsed.href, { redirect: "follow" });
    if (!photoRes.ok) throw new Error("Could not load that still.");
    const buf = Buffer.from(await photoRes.arrayBuffer());
    if (buf.length < 32 || buf.length > 2_500_000) throw new Error("Still is too large.");
    const mime = photoRes.headers.get("content-type") || "image/jpeg";
    if (!mime.startsWith("image/") && buf[0] !== 0xff) throw new Error("Bad still.");
    const photoData = `data:${mime.startsWith("image/") ? mime : "image/jpeg"};base64,${buf.toString("base64")}`;
    return recordGuestStill(hunt, {
      callsign: data.callsign,
      giftCard: data.giftCard,
      beat: data.beat,
      itemIndex: data.itemIndex,
      inBeat: data.inBeat,
      photoData,
    });
  });

export const receiveGuestStillData = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      callsign: nameSchema,
      giftCard: z.string().trim().max(40).default(""),
      beat: z.string().trim().max(24).default(""),
      itemIndex: z.number().int().min(0).max(99),
      inBeat: z.enum(["in", "out", ""]).default(""),
      photoData: z.string().min(32).max(2_500_000),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    if (!data.photoData.startsWith("data:image/")) throw new Error("Bad still.");
    return recordGuestStill(hunt, data);
  });

export const publishPlayPage = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z
        .string()
        .trim()
        .min(4)
        .max(8)
        .transform((value) => value.toUpperCase()),
      html: z.string().min(80).max(400_000),
    }),
  )
  .handler(async ({ data }) => {
    const url = await uploadPlayHtml(data.html, data.code);
    if (!url) throw new Error("Could not make a player link.");
    return { url };
  });

async function recordGuestStill(
  hunt: HuntRow,
  data: {
    callsign: string;
    giftCard: string;
    beat: string;
    itemIndex: number;
    inBeat: "in" | "out" | "";
    photoData: string;
  },
) {
  const sql = await db();
  const items = await sql<ItemRow>`
    select id, hunt_id, sort_order, title, hint, points,
           coalesce(list_no, 1) as list_no
    from hunt_items
    where hunt_id = ${hunt.id}
    order by sort_order asc
  `;
  const item = items[data.itemIndex];
  if (!item) throw new Error("That find is not on this hunt.");
  const playerId = await upsertGuestPlayer(hunt, {
    callsign: data.callsign,
    giftCard: data.giftCard,
    beat: data.beat,
  });
  const note =
    data.inBeat === "in" ? "In beat" : data.inBeat === "out" ? "Not in beat" : "";
  const { randomUUID } = await cryptoBits();
  await sql.query(
    `insert into submissions (id, hunt_id, player_id, item_id, photo_data, note, status)
     values ($1,$2,$3,$4,$5,$6,'pending')
     on conflict (player_id, item_id)
     do update set photo_data = excluded.photo_data, note = excluded.note,
                   status = 'pending', created_at = now()`,
    [randomUUID(), hunt.id, playerId, item.id, data.photoData, note],
  );
  return { ok: true as const, playerId };
}

export const updateHunt = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      status: z.enum(["open", "closed"]).optional(),
      items: z
        .array(
          z.object({
            id: z.string().min(4).max(80),
            title: z.string().trim().min(2).max(80),
            hint: z.string().trim().max(160),
          }),
        )
        .min(1)
        .max(100)
        .optional(),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    const sql = await db();
    if (data.status) {
      await sql`update hunts set status = ${data.status} where id = ${hunt.id}`;
    }
    if (data.items) {
      for (const item of data.items) {
        await sql`
          update hunt_items
          set title = ${item.title}, hint = ${item.hint}
          where id = ${item.id} and hunt_id = ${hunt.id}
        `;
      }
    }
    return { ok: true as const };
  });

export const addHuntItems = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      items: extraListSchema,
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    if (hunt.status === "closed") throw new Error("This hunt is closed.");
    const sql = await db();
    const existing = await sql<{ n: number }>`
      select count(*)::int as n from hunt_items where hunt_id = ${hunt.id}
    `;
    const count = asInt(existing[0]?.n);
    if (count + data.items.length > 100) {
      throw new Error("This hunt already has as many finds as it can hold.");
    }
    const lists = await sql<{ n: number }>`
      select coalesce(max(list_no), 0)::int as n from hunt_items where hunt_id = ${hunt.id}
    `;
    const listNo = Math.max(1, asInt(lists[0]?.n) + 1);
    await upsertItems(
      hunt.id,
      data.items.map((item) => ({
        title: item.title,
        hint: item.hint,
        listNo,
      })),
    );
    return { ok: true as const, added: data.items.length, listNo };
  });

export const setSubmissionStatus = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      submissionId: z.string().min(8),
      status: z.enum(["pending", "counted", "rejected"]),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    const sql = await db();
    await sql`
      update submissions
      set status = ${data.status}
      where id = ${data.submissionId} and hunt_id = ${hunt.id}
    `;
    return { ok: true as const };
  });

export const getSubmissionPhoto = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      submissionId: z.string().min(8),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    const sql = await db();
    const rows = await sql<{ photo_data: string; note: string; callsign: string; title: string }>`
      select s.photo_data, s.note, p.callsign, i.title
      from submissions s
      join players p on p.id = s.player_id
      join hunt_items i on i.id = s.item_id
      where s.id = ${data.submissionId} and s.hunt_id = ${hunt.id}
      limit 1
    `;
    const row = rows[0];
    if (!row) throw new Error("Photo not found.");
    return {
      photoData: row.photo_data,
      note: row.note,
      callsign: row.callsign,
      title: row.title,
    };
  });

async function runSpin(hunt: HuntRow, pool: WheelPool, skip: string[]) {
  const board = await assembleBoard(hunt, "host", null, []);
  const cards = board.players
    .map((p) => p.giftCardPick.trim())
    .filter((card) => card.length >= 2);
  if (cards.length === 0) {
    throw new Error("Nobody has picked a gift card yet.");
  }
  const { randomBytes, randomUUID } = await cryptoBits();
  const byte = randomBytes(4).readUInt32BE(0);
  const index = byte % cards.length;
  const card = cards[index]!;
  const slice = 360 / cards.length;
  const rotation = Math.round(6 * 360 + (360 - (index + 0.5) * slice));
  const declared = board.players.find((p) => p.id === hunt.declared_winner_id);
  const owner = board.players.find((p) => p.giftCardPick === card) ?? board.players[0];
  const fk = declared ?? owner;
  if (!fk) throw new Error("No players have joined yet.");
  const sql = await db();
  const id = randomUUID();
  await sql.query(
    `insert into wheel_spins (id, hunt_id, winner_player_id, pool, rotation, outcome, landed_card)
     values ($1,$2,$3,$4,$5,'pending',$6)`,
    [id, hunt.id, fk.id, pool, rotation, card],
  );
  return {
    spin: {
      id,
      winnerPlayerId: fk.id,
      winnerCallsign: declared?.callsign ?? fk.callsign,
      landedGiftCard: card,
      pool,
      rotation,
      outcome: "pending" as const,
      createdAt: new Date().toISOString(),
    } satisfies WheelSpin,
    giftCardPick: card,
  };
}

export const spinWheel = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      pool: z.enum(["all", "complete"]).default("all"),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    return runSpin(hunt, data.pool, parseIds(hunt.skip_ids));
  });

export const resolveWheel = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
      action: z.enum(["accept", "donate", "deduct"]),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    const sql = await db();
    const spins = await sql<SpinRow>`
      select id, hunt_id, winner_player_id, pool, rotation,
             coalesce(outcome,'pending') as outcome,
             coalesce(landed_card,'') as landed_card,
             created_at::text as created_at
      from wheel_spins
      where hunt_id = ${hunt.id}
      order by created_at desc
      limit 1
    `;
    const spin = spins[0];
    if (!spin || spin.outcome !== "pending") {
      throw new Error("Spin first.");
    }

    if (data.action === "accept") {
      await sql`update wheel_spins set outcome = 'accepted' where id = ${spin.id}`;
      await sql`update hunts set skip_ids = '[]' where id = ${hunt.id}`;
      return { action: "accept" as const, spin: null, giftCardPick: "" };
    }

    if (data.action === "donate") {
      await sql`update wheel_spins set outcome = 'donated' where id = ${spin.id}`;
      const skip = [...parseIds(hunt.skip_ids), spin.winner_player_id];
      await sql`update hunts set skip_ids = ${JSON.stringify(skip)} where id = ${hunt.id}`;
      const next = await runSpin(hunt, spin.pool === "complete" ? "complete" : "all", skip);
      return { action: "donate" as const, ...next };
    }

    await sql`update wheel_spins set outcome = 'deducted' where id = ${spin.id}`;
    const remaining = Math.max(0, asInt(hunt.pot_remaining) - 10);
    await sql`update hunts set pot_remaining = ${remaining} where id = ${hunt.id}`;
    const next = await runSpin(
      hunt,
      spin.pool === "complete" ? "complete" : "all",
      parseIds(hunt.skip_ids),
    );
    return { action: "deduct" as const, ...next };
  });

export const exportHunt = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      hostToken: z.string().min(8),
    }),
  )
  .handler(async ({ data }) => {
    const hunt = await requireHost(data.code, data.hostToken);
    const sql = await db();
    const items = await sql<ItemRow>`
      select id, hunt_id, sort_order, title, hint, points
      from hunt_items where hunt_id = ${hunt.id} order by sort_order
    `;
    const players = await sql<PlayerDbRow>`
      select id, hunt_id, token_hash, callsign, gift_card_pick,
             coalesce(beat,'') as beat, joined_at::text as joined_at
      from players where hunt_id = ${hunt.id}
    `;
    const subs = await sql<SubRow>`
      select id, hunt_id, player_id, item_id, photo_data, note, status,
             created_at::text as created_at
      from submissions where hunt_id = ${hunt.id}
    `;
    return {
      version: 2 as const,
      exportedAt: new Date().toISOString(),
      hunt: {
        title: hunt.title,
        adminName: hunt.admin_name,
        environment: hunt.environment,
        potEnabled: asBool(hunt.pot_enabled),
        potPerPlayer: asInt(hunt.pot_per_player),
        potRemaining: asInt(hunt.pot_remaining),
        status: hunt.status,
      },
      items: items.map((i) => ({
        sortOrder: i.sort_order,
        title: i.title,
        hint: i.hint,
      })),
      players: players.map((p) => ({
        callsign: p.callsign,
        giftCardPick: p.gift_card_pick,
        beat: p.beat,
      })),
      submissions: subs.map((s) => ({
        playerCallsign: players.find((p) => p.id === s.player_id)?.callsign ?? "",
        itemIndex: items.findIndex((i) => i.id === s.item_id),
        photoData: s.photo_data,
        note: s.note,
        status: s.status,
      })),
    };
  });

export const importHunt = createServerFn({ method: "POST" })
  .validator(z.object({ payload: z.string().min(20).max(6_000_000) }))
  .handler(async ({ data }) => {
    let parsed: {
      hunt?: {
        adminName?: string;
        environment?: string;
        potEnabled?: boolean;
        potPerPlayer?: number;
        title?: string;
      };
      items?: { title?: string; hint?: string }[];
    };
    try {
      parsed = JSON.parse(data.payload) as typeof parsed;
    } catch {
      throw new Error("That file is not valid JSON.");
    }
    const environment = asEnv(parsed.hunt?.environment ?? "family");
    const env = envById(environment);
    const rawItems = Array.isArray(parsed.items) ? parsed.items : [];
    const items = rawItems
      .map((item) => ({
        title: (item?.title ?? "").trim().slice(0, 80),
        hint: (item?.hint ?? "").trim().slice(0, 160),
      }))
      .filter((item) => item.title.length >= 2)
      .slice(0, 100);
    const opening = items.length > 0 ? items : env.items.map((item) => ({ ...item }));
    return createHunt({
      data: {
        adminName: (parsed.hunt?.adminName ?? "Admin").slice(0, 24) || "Admin",
        environment,
        potEnabled: Boolean(parsed.hunt?.potEnabled),
        potPerPlayer: Math.max(0, Number(parsed.hunt?.potPerPlayer) || 0),
        items: opening,
      },
    });
  });

export const publishPlayerPage = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().trim().min(4).max(8),
      environment: envSchema,
      potEnabled: z.boolean(),
      potPerPlayer: z.number().int().min(0).max(10000),
      items: z.array(z.string().trim().min(2).max(80)).min(1).max(100),
    }),
  )
  .handler(async ({ data }) => {
    const code = data.code.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const html = buildPlayerHtml({
      code,
      environment: data.environment,
      adminName: "Admin",
      potEnabled: data.potEnabled,
      potPerPlayer: data.potPerPlayer,
      items: data.items.map((title) => ({ title, hint: "" })),
    });
    const { uploadPlayHtml } = await import("@/lib/play-link");
    const url = await uploadPlayHtml(html, code);
    if (!url) throw new Error("Could not make a play link.");
    return { url };
  });
