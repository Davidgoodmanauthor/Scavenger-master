const HOST_KEY = "sm.hostTokens.v1";
const PLAYER_KEY = "sm.playerTokens.v1";
const LAST_KEY = "sm.lastHunt.v1";

type HostMap = Record<string, { token: string; title: string }>;
type PlayerMap = Record<string, { token: string; callsign: string; title: string }>;

function readJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function rememberHostToken(code: string, token: string, title = "") {
  const map = readJson<HostMap>(HOST_KEY, {});
  const existing = map[code.toUpperCase()];
  map[code.toUpperCase()] = {
    token,
    title: title || existing?.title || "",
  };
  writeJson(HOST_KEY, map);
}

export function getHostToken(code: string): string | null {
  const map = readJson<HostMap>(HOST_KEY, {});
  const row = map[code.toUpperCase()];
  if (!row) return null;
  if (typeof row === "string") return row;
  return row.token;
}

export function listHostedHunts(): { code: string; title: string }[] {
  const map = readJson<HostMap>(HOST_KEY, {});
  return Object.entries(map).map(([code, row]) => ({
    code,
    title: typeof row === "string" ? "" : row.title,
  }));
}

export function rememberPlayer(
  code: string,
  token: string,
  callsign: string,
  title = "",
) {
  const map = readJson<PlayerMap>(PLAYER_KEY, {});
  const existing = map[code.toUpperCase()];
  map[code.toUpperCase()] = {
    token,
    callsign,
    title: title || existing?.title || "",
  };
  writeJson(PLAYER_KEY, map);
}

export function getPlayerSession(code: string): { token: string; callsign: string } | null {
  const map = readJson<PlayerMap>(PLAYER_KEY, {});
  const row = map[code.toUpperCase()];
  if (!row) return null;
  return { token: row.token, callsign: row.callsign };
}

export function listJoinedHunts(): { code: string; title: string; callsign: string }[] {
  const map = readJson<PlayerMap>(PLAYER_KEY, {});
  return Object.entries(map).map(([code, row]) => ({
    code,
    title: row.title,
    callsign: row.callsign,
  }));
}

export function rememberLastHunt(code: string, role: "host" | "player") {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(
    LAST_KEY,
    JSON.stringify({ code: code.toUpperCase(), role }),
  );
}

export function getLastHunt(): { code: string; role: "host" | "player" } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(LAST_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { code?: string; role?: string };
    if (!parsed.code) return null;
    return {
      code: parsed.code.toUpperCase(),
      role: parsed.role === "host" ? "host" : "player",
    };
  } catch {
    return null;
  }
}

export function clearOldHunts() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(HOST_KEY);
  window.localStorage.removeItem(LAST_KEY);
}
