import type { EnvironmentId, ItemDraft } from "./types";

export type HuntEnvironment = {
  id: EnvironmentId;
  name: string;
  banner: string;
  blurb: string;
  items: ItemDraft[];
  beatRule?: string;
};

export const ENVIRONMENTS: HuntEnvironment[] = [
  {
    id: "police",
    name: "Police",
    banner: "/banners/police.jpg?v=k9",
    blurb: "Finds on the street. Nothing that belongs in a report.",
    beatRule: "Photos must be taken on your assigned beat.",
    items: [
      { title: "A landmark on your beat", hint: "Something people give directions from." },
      { title: "Something older than the radio", hint: "Weathered, chipped, still standing." },
      { title: "A quiet street at its best", hint: "Empty pavement, good light." },
      { title: "Proof you stopped for coffee", hint: "Cup, shop, receipt — no faces needed." },
      { title: "A view you'd never write up", hint: "The one you actually like." },
    ],
  },
  {
    id: "fire",
    name: "Fire and EMS",
    banner: "/banners/fire.jpg",
    blurb: "House, bay, and the quiet between calls.",
    items: [
      { title: "The engine that would roll first", hint: "From the rear or the bay is fine." },
      { title: "Something that still shines after a long shift", hint: "Chrome, glass, or a floor." },
      { title: "A door you hope you never need", hint: "Include the handle or number." },
      { title: "The kitchen at its honest hour", hint: "No faces in frame." },
      { title: "A view from the bay", hint: "Doors open or closed." },
    ],
  },
  {
    id: "office",
    name: "Office",
    banner: "/banners/office.jpg",
    blurb: "For the crew that lives under fluorescent lights.",
    items: [
      { title: "Oldest object still in use", hint: "If it still works, it counts." },
      { title: "A plant that's surviving", hint: "Barely counts." },
      { title: "Something that shouldn't be that color", hint: "You'll know it when you see it." },
      { title: "The best snack stash", hint: "No names on the stash." },
      { title: "A door nobody uses", hint: "Include the handle or number." },
    ],
  },
  {
    id: "warehouse",
    name: "Warehouse",
    banner: "/banners/warehouse.jpg",
    blurb: "Aisles, docks, and whatever does not belong.",
    items: [
      { title: "A pallet you'd know in the dark", hint: "No readable customer names." },
      { title: "Oldest equipment still working", hint: "If it runs, it counts." },
      { title: "A safety sign that's seen some years", hint: "Faded is better." },
      { title: "The dock at its quietest", hint: "Doors, trailers, or empty concrete." },
      { title: "Something that does not belong in this aisle", hint: "You'll know it." },
    ],
  },
  {
    id: "school",
    name: "School or teachers",
    banner: "/banners/school.jpg",
    blurb: "Hallways, rooms, and the coffee situation.",
    items: [
      { title: "A hallway at its quietest", hint: "No students in frame." },
      { title: "Something left behind", hint: "No names, no faces." },
      { title: "The oldest poster still on a wall", hint: "Corners curling is a plus." },
      { title: "A classroom light with a story", hint: "Flicker counts." },
      { title: "The teacher's coffee situation", hint: "Mug, machine, or survival station." },
    ],
  },
  {
    id: "family",
    name: "Family and friends",
    banner: "/banners/family.jpg",
    blurb: "Kids, dogs, and whoever wandered over after dinner.",
    items: [
      { title: "Something that starts with S", hint: "Stone, stick, squirrel, sky — your call." },
      { title: "A leaf bigger than your hand", hint: "Lay your hand next to it." },
      { title: "Four-legged neighbor, or tracks", hint: "Keep your distance. Tracks count." },
      { title: "A hidden path or shortcut", hint: "The way you actually walk." },
      { title: "The color of the sky right now", hint: "Hold something in frame so we can see it." },
    ],
  },
  {
    id: "other",
    name: "Other",
    banner: "/banners/other.jpg",
    blurb: "Anywhere. Rewrite the list to fit.",
    items: [
      { title: "Something red", hint: "Fill the frame with it." },
      { title: "A number in the wild", hint: "House, sign, jersey — no faces." },
      { title: "Something that makes a sound", hint: "Show the source." },
      { title: "A reflection", hint: "Puddle, glass, or chrome." },
      { title: "The farthest thing you can walk to in five minutes", hint: "Turn around and shoot it." },
    ],
  },
];

export const DEFAULT_ENVIRONMENT: EnvironmentId = "family";

export function envById(id: string | undefined): HuntEnvironment {
  return ENVIRONMENTS.find((e) => e.id === id) ?? ENVIRONMENTS.find((e) => e.id === "family")!;
}

export const PLAYER_STORES = [
  "Amazon",
  "Target",
  "Walmart",
  "Visa",
  "Starbucks",
  "Bass Pro",
  "Home Depot",
  "Apple",
  "Other",
];

export function normalizeGiftCard(store: string, other = ""): string {
  const pick = store.trim();
  if (!pick) return "";
  if (pick.toLowerCase() === "other") return other.trim().slice(0, 40);
  return pick.slice(0, 40);
}
