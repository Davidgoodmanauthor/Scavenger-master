import type { ErrorComponentProps } from "@tanstack/react-router";

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg">
      <h1 className="font-display text-2xl">Could not open</h1>
      <p className="max-w-md text-sm break-words text-muted">
        {error.message || "The hunt did not load. Close this and tap Play again."}
      </p>
      <a
        href="/"
        className="inline-flex h-12 items-center justify-center rounded-md bg-accent px-5 text-base font-medium text-accent-fg no-underline"
      >
        Open again
      </a>
    </main>
  );
}
