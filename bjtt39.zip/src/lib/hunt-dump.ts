const DUMP_DIR = "/workspace/.data/hunts";

export type HuntDump = {
  version: 3;
  savedAt: string;
  hunt: Record<string, unknown>;
  items: Record<string, unknown>[];
  players: Record<string, unknown>[];
  submissions: Record<string, unknown>[];
  spins: Record<string, unknown>[];
};

function dumpEnabled() {
  if (typeof process === "undefined") return false;
  if (process.env.DATABASE_URL?.trim()) return false;
  return true;
}

function fileFor(code: string) {
  return `${DUMP_DIR}/${code.toUpperCase()}.json`;
}

async function sql() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

export async function persistHuntDump(huntId: string, joinCode: string) {
  if (!dumpEnabled()) return;
  try {
    const db = await sql();
    const hunts = await db.query<Record<string, unknown>>(
      `select id, join_code, host_token_hash, title, notes,
              coalesce(admin_name,'') as admin_name,
              coalesce(environment,'family') as environment,
              coalesce(pot_enabled, false) as pot_enabled,
              coalesce(pot_per_player, 0) as pot_per_player,
              coalesce(pot_remaining, 0) as pot_remaining,
              coalesce(skip_ids,'[]') as skip_ids,
              status, created_at::text as created_at
       from hunts where id = $1 limit 1`,
      [huntId],
    );
    const hunt = hunts[0];
    if (!hunt) return;
    const items = await db.query<Record<string, unknown>>(
      `select id, hunt_id, sort_order, title, hint, points, coalesce(list_no, 1) as list_no from hunt_items where hunt_id = $1 order by sort_order`,
      [huntId],
    );
    const players = await db.query<Record<string, unknown>>(
      `select id, hunt_id, token_hash, callsign, gift_card_pick, coalesce(beat,'') as beat, joined_at::text as joined_at
       from players where hunt_id = $1`,
      [huntId],
    );
    const submissions = await db.query<Record<string, unknown>>(
      `select id, hunt_id, player_id, item_id, photo_data, note, status, created_at::text as created_at
       from submissions where hunt_id = $1`,
      [huntId],
    );
    const spins = await db.query<Record<string, unknown>>(
      `select id, hunt_id, winner_player_id, pool, rotation, coalesce(outcome,'pending') as outcome, created_at::text as created_at
       from wheel_spins where hunt_id = $1`,
      [huntId],
    );
    const { mkdir, writeFile } = await import("node:fs/promises");
    await mkdir(DUMP_DIR, { recursive: true });
    const payload: HuntDump = {
      version: 3,
      savedAt: new Date().toISOString(),
      hunt,
      items,
      players,
      submissions,
      spins,
    };
    await writeFile(fileFor(joinCode), JSON.stringify(payload));
  } catch {
    // preview-only backup — never block the hunt
  }
}

export async function restoreHuntDump(code: string): Promise<boolean> {
  if (!dumpEnabled()) return false;
  try {
    const { readFile } = await import("node:fs/promises");
    const raw = await readFile(fileFor(code), "utf8");
    const dump = JSON.parse(raw) as HuntDump;
    if (!dump?.hunt?.id || !Array.isArray(dump.items)) return false;
    const db = await sql();
    const hunt = dump.hunt;
    await db.query(
      `insert into hunts (
         id, join_code, host_token_hash, title, notes, admin_name, environment,
         pot_enabled, pot_per_player, pot_remaining, skip_ids, gift_cards, prize_pot, status
       ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'[]','',$12)
       on conflict (join_code) do nothing`,
      [
        hunt.id,
        String(hunt.join_code ?? code).toUpperCase(),
        hunt.host_token_hash,
        hunt.title ?? "Hunt",
        hunt.notes ?? "",
        hunt.admin_name ?? "",
        hunt.environment ?? "family",
        hunt.pot_enabled ?? false,
        hunt.pot_per_player ?? 0,
        hunt.pot_remaining ?? 0,
        hunt.skip_ids ?? "[]",
        hunt.status === "closed" ? "closed" : "open",
      ],
    );
    for (const item of dump.items) {
      await db.query(
        `insert into hunt_items (id, hunt_id, sort_order, title, hint, points, list_no)
         values ($1,$2,$3,$4,$5,$6,$7)
         on conflict (id) do nothing`,
        [
          item.id,
          hunt.id,
          item.sort_order ?? 0,
          item.title ?? "Find",
          item.hint ?? "",
          item.points ?? 1,
          item.list_no ?? Math.floor(Number(item.sort_order ?? 0) / 5) + 1,
        ],
      );
    }
    for (const player of dump.players ?? []) {
      await db.query(
        `insert into players (id, hunt_id, token_hash, callsign, gift_card_pick, beat)
         values ($1,$2,$3,$4,$5,$6)
         on conflict (id) do nothing`,
        [
          player.id,
          hunt.id,
          player.token_hash,
          player.callsign,
          player.gift_card_pick ?? "",
          player.beat ?? "",
        ],
      );
    }
    for (const sub of dump.submissions ?? []) {
      await db.query(
        `insert into submissions (id, hunt_id, player_id, item_id, photo_data, note, status)
         values ($1,$2,$3,$4,$5,$6,$7)
         on conflict (player_id, item_id) do nothing`,
        [
          sub.id,
          hunt.id,
          sub.player_id,
          sub.item_id,
          sub.photo_data ?? "",
          sub.note ?? "",
          sub.status ?? "pending",
        ],
      );
    }
    for (const spin of dump.spins ?? []) {
      await db.query(
        `insert into wheel_spins (id, hunt_id, winner_player_id, pool, rotation, outcome)
         values ($1,$2,$3,$4,$5,$6)
         on conflict (id) do nothing`,
        [
          spin.id,
          hunt.id,
          spin.winner_player_id,
          spin.pool ?? "all",
          spin.rotation ?? 0,
          spin.outcome ?? "pending",
        ],
      );
    }
    return true;
  } catch {
    return false;
  }
}
