export function stillsTopic(code: string): string {
  return `smhunt${code.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()}`;
}

export function stillsPublishUrl(code: string): string {
  return `https://ntfy.sh/${stillsTopic(code)}`;
}

export function pingList(code: string, titles: string[]) {
  const items = titles
    .map((title) => title.replace(/~/g, " ").trim())
    .filter((title) => title.length >= 2);
  if (!items.length) return;
  const body = JSON.stringify({ k: "list", i: items.join("~") });
  try {
    void fetch(stillsPublishUrl(code), { method: "POST", body, keepalive: true });
  } catch {
    // player polls this topic
  }
}

export function pingGrade(
  code: string,
  callsign: string,
  itemIndex: number,
  status: "counted" | "rejected",
) {
  const body = JSON.stringify({
    k: "grade",
    n: callsign,
    i: itemIndex,
    s: status === "counted" ? "ok" : "no",
  });
  try {
    void fetch(stillsPublishUrl(code), { method: "POST", body, keepalive: true });
  } catch {
    // same topic the player already uses
  }
}

export function stillsPollUrl(code: string): string {
  return `https://ntfy.sh/${stillsTopic(code)}/json?poll=1&since=all`;
}

export type GuestJoin = {
  kind: "join";
  id: string;
  callsign: string;
  giftCard: string;
  beat: string;
};

export type GuestStill = {
  kind: "still";
  id: string;
  callsign: string;
  giftCard: string;
  beat: string;
  inBeat: "in" | "out" | "";
  itemIndex: number;
  title: string;
  photoUrl: string;
};

export type GuestPart = {
  kind: "part";
  id: string;
  callsign: string;
  giftCard: string;
  beat: string;
  inBeat: "in" | "out" | "";
  itemIndex: number;
  title: string;
  part: number;
  total: number;
  data: string;
};

export type GuestPing = {
  kind: "ping";
  id: string;
  callsign: string;
  giftCard: string;
  beat: string;
  inBeat: "in" | "out" | "";
  itemIndex: number;
  title: string;
};

export type GuestMessage = GuestJoin | GuestStill | GuestPart | GuestPing;

function fromB64url(s: string) {
  let t = s.replace(/-/g, "+").replace(/_/g, "/");
  while (t.length % 4) t += "=";
  return t;
}

function coerceMessage(raw: string): Record<string, unknown> | null {
  try {
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    if (!raw.includes("=") || !raw.includes("k=")) return null;
    const msg: Record<string, string> = {};
    for (const pair of raw.split("&")) {
      const eq = pair.indexOf("=");
      if (eq < 1) continue;
      const k = decodeURIComponent(pair.slice(0, eq).replace(/\+/g, " "));
      const v = decodeURIComponent(pair.slice(eq + 1).replace(/\+/g, " "));
      msg[k] = v;
    }
    return msg;
  }
}

export function parseGuestMessage(
  raw: string,
  id: string,
  attachmentUrl = "",
): GuestMessage | null {
  try {
    const msg = coerceMessage(raw);
    if (!msg) return null;
    if (msg.k === "grade" || msg.k === "list") return null;
    const callsign = String(msg.n ?? "").trim();
    if (callsign.length < 2) return null;
    const giftCard = String(msg.s ?? "").trim().slice(0, 40);
    const beat = String(msg.b ?? "").trim().slice(0, 24);
    const inBeat = msg.ib === "in" || msg.ib === "out" ? msg.ib : "";
    const itemIndex = Math.max(0, Math.min(99, Number(msg.i) || 0));
    const title = String(msg.t ?? "").trim().slice(0, 80);
    const inline = fromB64url(String(msg.d ?? ""));
    const photoUrl = (attachmentUrl || String(msg.u ?? "")).trim();
    if (msg.k === "still") {
      if (inline.length > 32) {
        return {
          kind: "part",
          id,
          callsign: callsign.slice(0, 24),
          giftCard,
          beat,
          inBeat,
          itemIndex,
          title,
          part: 0,
          total: 1,
          data: inline,
        };
      }
      if (photoUrl.startsWith("https://")) {
        return {
          kind: "still",
          id,
          callsign: callsign.slice(0, 24),
          giftCard,
          beat,
          inBeat,
          itemIndex,
          title,
          photoUrl,
        };
      }
      return {
        kind: "ping",
        id,
        callsign: callsign.slice(0, 24),
        giftCard,
        beat,
        inBeat,
        itemIndex,
        title,
      };
    }
    if (msg.k === "part") {
      const data = fromB64url(String(msg.d ?? ""));
      const total = Math.max(1, Math.min(80, Number(msg.c) || 0));
      const part = Math.max(0, Number(msg.p) || 0);
      if (!data || part >= total) return null;
      return {
        kind: "part",
        id,
        callsign: callsign.slice(0, 24),
        giftCard,
        beat,
        inBeat,
        itemIndex,
        title,
        part,
        total,
        data,
      };
    }
    if (msg.k === "join" || !photoUrl) {
      return {
        kind: "join",
        id,
        callsign: callsign.slice(0, 24),
        giftCard,
        beat,
      };
    }
    if (!photoUrl.startsWith("https://")) return null;
    return {
      kind: "still",
      id,
      callsign: callsign.slice(0, 24),
      giftCard,
      beat,
      inBeat,
      itemIndex,
      title,
      photoUrl,
    };
  } catch {
    return null;
  }
}

export function parseStillMessage(raw: string, id: string): GuestStill | null {
  const parsed = parseGuestMessage(raw, id);
  return parsed?.kind === "still" ? parsed : null;
}

export class StillAssembler {
  add(part: GuestPart): string | null {
    const key = `${part.callsign.toLowerCase()}::${part.itemIndex}::${part.total}`;
    let bag = this.bags.get(key);
    if (!bag) {
      bag = { total: part.total, chunks: Array<string | undefined>(part.total), got: 0 };
      this.bags.set(key, bag);
    }
    if (part.part >= bag.total) return null;
    if (bag.chunks[part.part] == null) {
      bag.chunks[part.part] = part.data;
      bag.got += 1;
    }
    if (bag.got < bag.total) return null;
    if (bag.chunks.some((chunk) => chunk == null)) return null;
    this.bags.delete(key);
    return `data:image/jpeg;base64,${bag.chunks.join("")}`;
  }

  private bags = new Map<string, { total: number; chunks: Array<string | undefined>; got: number }>();
}
