import type { EnvironmentId, HuntBoard, HuntSnapshot, ItemDraft } from "./types";
import { isPlayableUrl, playInviteUrl } from "./play-link";

const SNAP_KEY = "sm.guestSnap.v1";

export type { HuntSnapshot };

function readSnaps(): Record<string, HuntSnapshot> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(SNAP_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, HuntSnapshot>;
  } catch {
    return {};
  }
}

export function rememberSnapshot(snapshot: HuntSnapshot) {
  if (typeof window === "undefined") return;
  const map = readSnaps();
  map[snapshot.code.toUpperCase()] = snapshot;
  window.localStorage.setItem(SNAP_KEY, JSON.stringify(map));
}

export function peekSnapshot(code: string): HuntSnapshot | null {
  return readSnaps()[code.toUpperCase()] ?? null;
}

export function snapshotFromBoard(board: HuntBoard): HuntSnapshot {
  return {
    code: board.hunt.joinCode.toUpperCase(),
    environment: board.hunt.environment,
    adminName: board.hunt.adminName,
    potEnabled: board.hunt.potEnabled,
    potPerPlayer: board.hunt.potPerPlayer,
    items: board.items.map((item) => ({ title: item.title, hint: item.hint })),
  };
}

export function snapshotFromDraft(input: {
  code: string;
  environment: EnvironmentId;
  adminName: string;
  potEnabled: boolean;
  potPerPlayer: number;
  items: ItemDraft[];
}): HuntSnapshot {
  return {
    code: input.code.toUpperCase(),
    environment: input.environment,
    adminName: input.adminName.trim().slice(0, 24),
    potEnabled: Boolean(input.potEnabled),
    potPerPlayer: input.potEnabled ? Math.max(0, input.potPerPlayer) : 0,
    items: input.items.slice(0, 100).map((item) => ({
      title: item.title.trim().slice(0, 80),
      hint: (item.hint ?? "").trim().slice(0, 160),
    })),
  };
}

/** True when this host is a Grok/X preview that can put a login in front of a guest. */
export function originForcesLogin(hostname?: string): boolean {
  if (typeof window === "undefined" && !hostname) return true;
  const host = (hostname ?? window.location.hostname).toLowerCase();
  if (host === "localhost" || host === "127.0.0.1") return false;
  return (
    host.includes("grok") ||
    host.includes("hades") ||
    host.includes("sandbox") ||
    host === "x.com" ||
    host.endsWith(".x.com") ||
    host === "twitter.com" ||
    host.endsWith(".twitter.com") ||
    host === "x.ai" ||
    host.endsWith(".x.ai")
  );
}

export function encodeSnapshot(snapshot: HuntSnapshot): string {
  const body = JSON.stringify({
    v: 2,
    c: snapshot.code.toUpperCase(),
    e: snapshot.environment,
    a: snapshot.adminName,
    p: snapshot.potEnabled ? 1 : 0,
    n: snapshot.potPerPlayer,
    i: snapshot.items.map((item) => [item.title, item.hint ?? ""]),
  });
  const bytes = new TextEncoder().encode(body);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/g, "");
}

export function decodeSnapshot(raw: string): HuntSnapshot | null {
  try {
    const b64 = raw.replaceAll("-", "+").replaceAll("_", "/");
    const pad = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    const binary = atob(pad);
    const bytes = Uint8Array.from(binary, (ch) => ch.charCodeAt(0));
    const parsed = JSON.parse(new TextDecoder().decode(bytes)) as {
      c?: string;
      e?: string;
      a?: string;
      p?: number;
      n?: number;
      i?: [string, string][];
    };
    const code = (parsed.c ?? "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const env = parsed.e as EnvironmentId | undefined;
    const items = Array.isArray(parsed.i) ? parsed.i : [];
    if (code.length < 4 || !env || items.length < 1) return null;
    return {
      code,
      environment: env,
      adminName: String(parsed.a ?? "Admin").slice(0, 24),
      potEnabled: parsed.p === 1,
      potPerPlayer: Math.max(0, Number(parsed.n) || 0),
      items: items.map(([title, hint]) => ({ title: String(title), hint: String(hint ?? "") })),
    };
  } catch {
    return null;
  }
}

export function parseJoinHash(
  hash = typeof window === "undefined" ? "" : window.location.hash,
): { code: string; snapshot: HuntSnapshot | null } | null {
  const raw = hash.replace(/^#/, "").trim();
  if (!raw) return null;
  const params = new URLSearchParams(raw.includes("=") ? raw : `join=${raw}`);
  const code = (params.get("join") ?? "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
  if (code.length < 4 || code.length > 8) return null;
  const fromHash = params.get("h") ? decodeSnapshot(params.get("h")!) : null;
  const snapshot = fromHash ? { ...fromHash, code } : peekSnapshot(code);
  return { code, snapshot };
}

function stripLoginUrls(text: string): string {
  return text
    .replace(/https?:\/\/[^\s]+/gi, (url) => {
      try {
        const host = new URL(url).hostname.toLowerCase();
        if (originForcesLogin(host)) return "";
        if (host.includes("filebin")) return "";
        if (!isPlayableUrl(url) && !host.includes("catbox.moe")) return "";
      } catch {
        return "";
      }
      return url;
    })
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function rememberPlayUrl(code: string, url: string) {
  if (typeof window === "undefined") return;
  if (!url.startsWith("https://")) return;
  if (!isPlayableUrl(url)) return;
  try {
    const raw = window.localStorage.getItem("sm.playUrl.v1");
    const map = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    map[code.toUpperCase()] = url;
    window.localStorage.setItem("sm.playUrl.v1", JSON.stringify(map));
  } catch {
    // ignore
  }
}

export function peekPlayUrl(code: string): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("sm.playUrl.v1");
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, string>;
    const url = map[code.toUpperCase()];
    if (!url || !url.startsWith("https://")) return null;
    if (!isPlayableUrl(url)) return null;
    return url;
  } catch {
    return null;
  }
}

export function guestJoinUrl(snapshot: HuntSnapshot): string | null {
  return playInviteUrl(snapshot);
}

export function inviteText(snapshot: HuntSnapshot, playUrl?: string | null): string {
  const url = (playUrl && playUrl.startsWith("https://") ? playUrl : null) ?? guestJoinUrl(snapshot);
  const text = url
    ? `SCAVENGER MASTER\nHunt code: ${snapshot.code}\nTap this to play:\n${url}`
    : `SCAVENGER MASTER\nHunt code: ${snapshot.code}`;
  return stripLoginUrls(text);
}

export function smsInviteHref(snapshot: HuntSnapshot, playUrl?: string | null): string {
  const body = encodeURIComponent(inviteText(snapshot, playUrl));
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  if (/iPad|iPhone|iPod/i.test(ua)) return `sms:&body=${body}`;
  return `sms:?body=${body}`;
}

export function inviteWarning(): string {
  return "Opens your texts. Pick a person. They tap the link, type a name. No account.";
}

export function writeJoinHash(snapshot: HuntSnapshot) {
  if (typeof window === "undefined") return;
  const next = `join=${snapshot.code}&h=${encodeSnapshot(snapshot)}`;
  if (window.location.hash.replace(/^#/, "") === next) return;
  const url = `${window.location.pathname}${window.location.search}#${next}`;
  window.history.replaceState(window.history.state, "", url);
}
