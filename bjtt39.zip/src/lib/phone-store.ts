import type { BoardRole, HuntBoard, HuntSnapshot, YourPhoto } from "./types";
import { snapshotFromBoard } from "./invite";
import { getHostToken, rememberHostToken } from "./device";

const LS_KEY = "sm.boardCache.v1";
const META_KEY = "sm.huntMeta.v1";
const IDB_NAME = "sm-phone-v1";
const IDB_STORE = "hunts";

export type HuntCache = {
  code: string;
  board: HuntBoard;
  snapshot: HuntSnapshot;
  savedAt: number;
};

type HuntMeta = {
  code: string;
  snapshot: HuntSnapshot;
  role: BoardRole;
  title: string;
  savedAt: number;
  hostToken?: string;
};

const mem = new Map<string, HuntCache>();
let ready: Promise<void> | null = null;

function readJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // quota — caller already stored a smaller copy
  }
}

function readAllLs(): Record<string, HuntCache> {
  return readJson<Record<string, HuntCache>>(LS_KEY, {});
}

function readMeta(): Record<string, HuntMeta> {
  return readJson<Record<string, HuntMeta>>(META_KEY, {});
}

function boardFromMeta(meta: HuntMeta): HuntBoard {
  const snap = meta.snapshot;
  return {
    hunt: {
      id: snap.code,
      joinCode: snap.code,
      title: meta.title || "Hunt",
      adminName: snap.adminName,
      environment: snap.environment,
      notes: "",
      potEnabled: snap.potEnabled,
      potPerPlayer: snap.potPerPlayer,
      potRemaining: snap.potEnabled ? snap.potPerPlayer : 0,
      playerCount: 0,
      itemCount: snap.items.length,
      status: "open",
      declaredWinnerId: "",
      createdAt: new Date(meta.savedAt).toISOString(),
    },
    items: snap.items.map((item, i) => ({
      id: `item-${i}`,
      sortOrder: i,
      listNo: i + 1,
      title: item.title,
      hint: item.hint,
      points: 20,
    })),
    players: [],
    submissions: [],
    yourPhotos: [],
    latestSpin: null,
    role: meta.role === "guest" ? "guest" : meta.role,
    you: null,
  };
}

function openDb(): Promise<IDBDatabase | null> {
  if (typeof window === "undefined" || !window.indexedDB) return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = window.indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function hydrate() {
  const ls = readAllLs();
  for (const row of Object.values(ls)) {
    if (row?.code && row.board && row.snapshot) mem.set(row.code.toUpperCase(), row);
  }
  const db = await openDb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, "readonly");
      const store = tx.objectStore(IDB_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        for (const row of (req.result as HuntCache[]) ?? []) {
          if (row?.code && row.board && row.snapshot) mem.set(row.code.toUpperCase(), row);
        }
        resolve();
      };
      req.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export function whenPhoneStoreReady(): Promise<void> {
  if (!ready) ready = hydrate();
  return ready;
}

export function peekCachedHostToken(code: string): string | null {
  const meta = readMeta()[code.toUpperCase()];
  return meta?.hostToken || null;
}

export function loadBoardCache(code: string): HuntCache | null {
  const upper = code.toUpperCase();
  const hit = mem.get(upper);
  if (hit) return hit;
  const ls = readAllLs()[upper];
  if (ls?.board && ls.snapshot) {
    mem.set(upper, ls);
    return ls;
  }
  const meta = readMeta()[upper];
  if (!meta?.snapshot) return null;
  const synthesized: HuntCache = {
    code: upper,
    board: boardFromMeta(meta),
    snapshot: meta.snapshot,
    savedAt: meta.savedAt,
  };
  mem.set(upper, synthesized);
  return synthesized;
}

export function saveBoardCache(board: HuntBoard) {
  const code = board.hunt.joinCode.toUpperCase();
  const snapshot = snapshotFromBoard(board);
  const row: HuntCache = { code, board, snapshot, savedAt: Date.now() };
  mem.set(code, row);
  const meta = readMeta();
  meta[code] = {
    code,
    snapshot,
    role: board.role === "guest" ? "player" : board.role,
    title: board.hunt.title,
    savedAt: row.savedAt,
    hostToken: getHostToken(code) ?? undefined,
  };
  writeJson(META_KEY, meta);
  if (board.role === "host") {
    const token = getHostToken(code);
    if (token) rememberHostToken(code, token, board.hunt.title);
  }
  void openDb().then((db) => {
    if (!db) return;
    try {
      const tx = db.transaction(IDB_STORE, "readwrite");
      tx.objectStore(IDB_STORE).put(row, code);
    } catch {
      // ignore
    }
  });
}

export function listBoardCaches(): HuntCache[] {
  const codes = new Set<string>([...mem.keys(), ...Object.keys(readMeta())]);
  return [...codes]
    .map((code) => loadBoardCache(code))
    .filter((row): row is HuntCache => Boolean(row))
    .sort((a, b) => b.savedAt - a.savedAt);
}

export function rememberLocalPhoto(code: string, itemId: string, photoData: string) {
  const cache = loadBoardCache(code);
  if (!cache) return;
  const nextPhotos: YourPhoto[] = [
    ...cache.board.yourPhotos.filter((photo) => photo.itemId !== itemId),
    {
      itemId,
      submissionId: `local-${itemId}`,
      photoData,
      note: "",
      status: "pending",
    },
  ];
  const you = cache.board.you;
  const submissions = cache.board.submissions.filter(
    (s) => !(you && s.playerId === you.playerId && s.itemId === itemId),
  );
  if (you) {
    submissions.push({
      id: `local-${itemId}`,
      playerId: you.playerId,
      itemId,
      note: "",
      status: "pending",
      createdAt: new Date().toISOString(),
    });
  }
  saveBoardCache({ ...cache.board, yourPhotos: nextPhotos, submissions });
}

export function installPhonePersist() {
  if (typeof window === "undefined") return;
  const flush = () => {
    for (const row of mem.values()) {
      const meta = readMeta();
      meta[row.code] = {
        code: row.code,
        snapshot: row.snapshot,
        role: row.board.role === "guest" ? "player" : row.board.role,
        title: row.board.hunt.title,
        savedAt: Date.now(),
        hostToken: getHostToken(row.code) ?? undefined,
      };
      writeJson(META_KEY, meta);
    }
  };
  window.addEventListener("pagehide", flush);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flush();
  });
}

export function clearHuntCaches() {
  mem.clear();
  writeJson(META_KEY, {});
  writeJson(LS_KEY, {});
  try {
    window.indexedDB?.deleteDatabase(IDB_NAME);
  } catch {
    // ignore
  }
}
