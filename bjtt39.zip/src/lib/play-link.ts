import type { HuntSnapshot } from "./types";

/** Generic player page. Hunt data rides on the hash so Invite does not upload. */
export const PLAYER_SHELL_URL = "https://litter.catbox.moe/h0hoox.html";

export function playInviteUrl(snapshot: HuntSnapshot, shell = PLAYER_SHELL_URL): string {
  const items = snapshot.items
    .map((item) => item.title.replace(/[~|]/g, " ").trim())
    .filter((title) => title.length >= 2)
    .join("~");
  const d = [
    snapshot.code.toUpperCase(),
    snapshot.environment,
    String(snapshot.potEnabled ? snapshot.potPerPlayer : 0),
    items,
  ].join("|");
  const base = shell.split("#")[0].split("?")[0];
  return `${base}?d=${encodeURIComponent(d)}`;
}

export function isPlayableUrl(url: string): boolean {
  return /^https:\/\/(litter|files)\.catbox\.moe\/[A-Za-z0-9.]+(?:[?#].*)?$/i.test(url.trim());
}

export function huntBin(code: string): string {
  return `sm${code.replace(/[^a-zA-Z0-9]/g, "").toLowerCase()}`;
}

export function stillSlug(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 18) || "p";
}

export function parseStillFilename(filename: string): {
  slug: string;
  itemIndex: number;
  inBeat: "in" | "out" | "";
} | null {
  const match = /^p-([a-z0-9]+)-(\d+)(?:-(in|out|x))?\.jpg$/i.exec(filename.trim());
  if (!match) return null;
  const flag = (match[3] ?? "x").toLowerCase();
  return {
    slug: match[1].toLowerCase(),
    itemIndex: Math.max(0, Number(match[2]) || 0),
    inBeat: flag === "in" || flag === "out" ? flag : "",
  };
}

export function filebinStillUrl(code: string, filename: string): string {
  return `https://filebin.net/${huntBin(code)}/${filename}`;
}

async function postCatbox(endpoint: string, html: string, code: string, withTime: boolean): Promise<string | null> {
  const form = new FormData();
  form.append("reqtype", "fileupload");
  if (withTime) form.append("time", "72h");
  form.append("fileToUpload", new Blob([html], { type: "text/html" }), `play-${code}.html`);
  const res = await fetch(endpoint, { method: "POST", body: form });
  const text = await res.text();
  const match = text.match(/https:\/\/(?:litter|files)\.catbox\.moe\/[A-Za-z0-9.]+/i);
  const url = match?.[0] ?? "";
  return isPlayableUrl(url) ? `${url.split("?")[0]}?v=31` : null;
}

async function tryCatbox(html: string, code: string): Promise<string | null> {
  const endpoints: Array<[string, boolean]> = [
    ["https://litterbox.catbox.moe/resources/internals/api.php", true],
    ["https://catbox.moe/user/api.php", false],
  ];
  for (const [endpoint, withTime] of endpoints) {
    try {
      const url = await postCatbox(endpoint, html, code, withTime);
      if (url) return url;
    } catch {
      // next
    }
  }
  return null;
}

export async function uploadPlayHtml(html: string, code: string): Promise<string | null> {
  for (let i = 0; i < 3; i++) {
    const catbox = await tryCatbox(html, code);
    if (catbox) return catbox;
  }
  return null;
}

export async function ensurePlayUrl(snapshot: HuntSnapshot): Promise<string | null> {
  return playInviteUrl(snapshot);
}
