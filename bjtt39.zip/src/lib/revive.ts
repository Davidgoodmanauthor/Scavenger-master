import { hydrateHunt } from "@/lib/api";
import { getHostToken, getPlayerSession } from "@/lib/device";
import { loadBoardCache, whenPhoneStoreReady } from "@/lib/phone-store";

export function isMissingHunt(err: unknown) {
  const msg = err instanceof Error ? err.message : String(err);
  return /no hunt with that code|could not open that hunt|this phone does not have that hunt/i.test(
    msg,
  );
}

export async function reviveHunt(code: string) {
  await whenPhoneStoreReady();
  const cache = loadBoardCache(code);
  if (!cache) return false;
  const hostToken = getHostToken(code) ?? undefined;
  const player = getPlayerSession(code);
  try {
    await hydrateHunt({
      data: {
        code: cache.snapshot.code,
        environment: cache.snapshot.environment,
        adminName: cache.snapshot.adminName || "Admin",
        potEnabled: cache.snapshot.potEnabled,
        potPerPlayer: cache.snapshot.potPerPlayer,
        potRemaining: cache.board.hunt.potRemaining,
        status: cache.board.hunt.status,
        items: cache.board.items.map((item) => ({
          id: item.id,
          title: item.title,
          hint: item.hint,
          listNo: item.listNo,
        })),
        hostToken,
        playerToken: player?.token,
        callsign: player?.callsign,
        giftCard: cache.board.you?.giftCardPick,
        beat: cache.board.you?.beat,
      },
    });
    return true;
  } catch {
    return false;
  }
}

export async function callOrRevive<T>(code: string, fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    if (!isMissingHunt(err)) throw err;
    const ok = await reviveHunt(code);
    if (!ok) throw err;
    return await fn();
  }
}
