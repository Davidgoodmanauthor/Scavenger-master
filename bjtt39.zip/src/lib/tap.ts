type TapEvent = {
  button?: number;
  preventDefault?: () => void;
};

let lastTap = 0;
let lockUntil = 0;

/** Ignore leftover clicks after a screen change (Android ghost taps). */
export function lockTaps(ms = 700) {
  lockUntil = Date.now() + ms;
}

/** Fire once per gesture. Pointer/touch first — click is often lost on Android WebViews. */
export function tapHandlers(fn: () => void) {
  const fire = () => {
    const now = Date.now();
    if (now < lockUntil) return;
    if (now - lastTap < 450) return;
    lastTap = now;
    fn();
  };
  return {
    onPointerDown: (e: TapEvent) => {
      if (e.button && e.button !== 0) return;
      fire();
    },
    onTouchStart: () => fire(),
    onClick: (e: TapEvent) => {
      e.preventDefault?.();
      fire();
    },
  };
}
