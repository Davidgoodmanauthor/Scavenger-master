/** Inline body script. Applies day/night without React and restores mid-setup. */
export const THEME_BOOT = `(function(){
  var KEY="sm.mode.v1";
  var WIZARD="sm.wizard.v1";
  function read(){
    try{
      var s=localStorage.getItem(KEY);
      if(s==="day"||s==="night") return s;
      var t=new URLSearchParams(location.search).get("theme");
      if(t==="day"||t==="night") return t;
    }catch(e){}
    return "night";
  }
  function apply(mode){
    mode=mode==="day"?"day":"night";
    var bg=mode==="day"?"#f6f0e4":"#0c0b08";
    var fg=mode==="day"?"#1c160c":"#f3ead4";
    var r=document.documentElement;
    r.classList.remove("day","night");
    r.classList.add(mode);
    r.setAttribute("data-theme",mode);
    r.style.backgroundColor=bg;
    r.style.color=fg;
    var b=document.body;
    if(b){
      b.classList.remove("day","night");
      b.classList.add(mode);
      b.setAttribute("data-theme",mode);
      b.style.backgroundColor=bg;
      b.style.color=fg;
    }
    var meta=document.querySelector('meta[name="theme-color"]');
    if(meta) meta.setAttribute("content",bg);
    try{ localStorage.setItem(KEY,mode); }catch(e){}
    window.__smMode=mode;
    try{
      var u=new URL(location.href);
      if(mode==="day") u.searchParams.set("theme","day");
      else u.searchParams.delete("theme");
      history.replaceState(history.state,"",u.pathname+u.search+u.hash);
    }catch(e){}
    try{ window.dispatchEvent(new CustomEvent("sm-mode",{detail:mode})); }catch(e){}
  }
  window.__setSmMode=apply;
  apply(read());
  function restoreWizard(){
    try{
      if(location.pathname!=="/") return;
      var q=new URLSearchParams(location.search);
      if(q.get("join")) return;
      var raw=localStorage.getItem(WIZARD);
      if(!raw) return;
      var d=JSON.parse(raw);
      if(!d) return;
      var changed=false;
      if(!q.get("n")&&!q.get("name")&&d.adminName){
        q.set("n",String(d.adminName).slice(0,24));
        changed=true;
      }
      if(q.get("s")){
        if(changed){
          var keep="/?"+q.toString();
          if(keep!==location.pathname+location.search) location.replace(keep);
        }
        return;
      }
      if(!d.adminName) return;
      var p=new URLSearchParams();
      p.set("n",String(d.adminName).slice(0,24));
      if(d.step>=2&&d.step<=4) p.set("s",String(d.step));
      if(d.potOn===true) p.set("pot","yes");
      if(d.potOn===false) p.set("pot","no");
      if(d.potAmount) p.set("amt",String(d.potAmount));
      if(d.environment) p.set("env",String(d.environment));
      if(window.__smMode==="day") p.set("theme","day");
      var next="/?"+p.toString();
      if(next!==location.pathname+location.search) location.replace(next);
    }catch(e){}
  }
  restoreWizard();
  function fromEvent(e){
    var n=e.target;
    if(!n||!n.closest) return;
    var el=n.closest("[data-set-mode]");
    if(!el) return;
    var mode=el.getAttribute("data-set-mode");
    if(mode==="toggle") mode=window.__smMode==="day"?"night":"day";
    if(mode!=="day"&&mode!=="night") return;
    e.preventDefault();
    if(e.stopPropagation) e.stopPropagation();
    apply(mode);
  }
  document.addEventListener("pointerdown",fromEvent,true);
  document.addEventListener("touchstart",fromEvent,{capture:true,passive:false});
  document.addEventListener("click",fromEvent,true);
})();`;
