import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Mode = "night" | "day";
const KEY = "sm.mode.v1";

declare global {
  interface Window {
    __smMode?: Mode;
    __setSmMode?: (mode: Mode) => void;
  }
}

const ThemeCtx = createContext<{
  mode: Mode;
  toggle: () => void;
  setMode: (mode: Mode) => void;
}>({
  mode: "night",
  toggle: () => undefined,
  setMode: () => undefined,
});

function apply(mode: Mode) {
  if (typeof window !== "undefined" && typeof window.__setSmMode === "function") {
    window.__setSmMode(mode);
    return;
  }
  const root = document.documentElement;
  const body = document.body;
  const bg = mode === "day" ? "#f6f0e4" : "#0c0b08";
  const fg = mode === "day" ? "#1c160c" : "#f3ead4";
  root.classList.remove("day", "night");
  root.classList.add(mode);
  root.dataset.theme = mode;
  root.style.backgroundColor = bg;
  root.style.color = fg;
  if (body) {
    body.classList.remove("day", "night");
    body.classList.add(mode);
    body.dataset.theme = mode;
    body.style.backgroundColor = bg;
    body.style.color = fg;
  }
}

function readMode(): Mode {
  if (typeof window === "undefined") return "night";
  if (window.__smMode === "day" || window.__smMode === "night") return window.__smMode;
  try {
    const saved = window.localStorage.getItem(KEY);
    if (saved === "day" || saved === "night") return saved;
  } catch {
    // private mode
  }
  return "night";
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<Mode>(readMode);

  useEffect(() => {
    const next = readMode();
    setModeState(next);
    apply(next);
    const onMode = (event: Event) => {
      const detail = (event as CustomEvent<Mode>).detail;
      if (detail === "day" || detail === "night") setModeState(detail);
    };
    window.addEventListener("sm-mode", onMode);
    return () => window.removeEventListener("sm-mode", onMode);
  }, []);

  function setMode(next: Mode) {
    apply(next);
    setModeState(next);
  }

  function toggle() {
    const current =
      typeof window !== "undefined" && (window.__smMode === "day" || window.__smMode === "night")
        ? window.__smMode
        : mode;
    setMode(current === "night" ? "day" : "night");
  }

  return (
    <ThemeCtx.Provider value={{ mode, toggle, setMode }}>
      <div className="min-h-dvh" suppressHydrationWarning>
        {children}
      </div>
    </ThemeCtx.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeCtx);
}
