export type HuntStatus = "open" | "closed";
export type SubmissionStatus = "pending" | "counted" | "rejected";
export type WheelPool = "all" | "complete";
export type WheelOutcome = "pending" | "accepted" | "donated" | "deducted";
export type BoardRole = "host" | "player" | "guest";
export type EnvironmentId =
  | "police"
  | "fire"
  | "office"
  | "warehouse"
  | "school"
  | "family"
  | "other";

export type HuntItem = {
  id: string;
  sortOrder: number;
  listNo: number;
  title: string;
  hint: string;
  points: number;
};

export type HuntSummary = {
  id: string;
  joinCode: string;
  title: string;
  adminName: string;
  environment: EnvironmentId;
  notes: string;
  potEnabled: boolean;
  potPerPlayer: number;
  potRemaining: number;
  playerCount: number;
  itemCount: number;
  status: HuntStatus;
  declaredWinnerId: string;
  createdAt: string;
};

export type PlayerRow = {
  id: string;
  callsign: string;
  giftCardPick: string;
  beat: string;
  joinedAt: string;
  completed: number;
  pending: number;
  points: number;
};

export type SubmissionMeta = {
  id: string;
  playerId: string;
  itemId: string;
  note: string;
  status: SubmissionStatus;
  createdAt: string;
};

export type YourPhoto = {
  itemId: string;
  submissionId: string;
  photoData: string;
  note: string;
  status: SubmissionStatus;
};

export type WheelSpin = {
  id: string;
  winnerPlayerId: string;
  winnerCallsign: string;
  landedGiftCard: string;
  pool: WheelPool;
  rotation: number;
  outcome: WheelOutcome;
  createdAt: string;
};

export type HuntBoard = {
  hunt: HuntSummary;
  items: HuntItem[];
  players: PlayerRow[];
  submissions: SubmissionMeta[];
  yourPhotos: YourPhoto[];
  latestSpin: WheelSpin | null;
  role: BoardRole;
  you: {
    playerId: string;
    callsign: string;
    giftCardPick: string;
    beat: string;
  } | null;
};

export type ItemDraft = {
  title: string;
  hint: string;
};

export type HuntSnapshot = {
  code: string;
  environment: EnvironmentId;
  adminName: string;
  potEnabled: boolean;
  potPerPlayer: number;
  items: ItemDraft[];
};
