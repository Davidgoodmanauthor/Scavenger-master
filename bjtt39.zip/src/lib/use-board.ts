import { useQuery } from "@tanstack/react-query";
import { getBoard, submitPhoto } from "@/lib/api";
import { getHostToken, getPlayerSession, rememberLastHunt } from "@/lib/device";
import { rememberSnapshot, snapshotFromBoard } from "@/lib/invite";
import { loadBoardCache, saveBoardCache, whenPhoneStoreReady } from "@/lib/phone-store";
import { reviveHunt } from "@/lib/revive";

export function useBoard(code: string, prefer: "auto" | "host" | "player" = "auto") {
  const upper = code.toUpperCase();
  const hostToken = getHostToken(upper);
  const player = getPlayerSession(upper);
  const cached = loadBoardCache(upper)?.board;

  const payload = {
    code: upper,
    hostToken: prefer === "player" ? undefined : (hostToken ?? undefined),
    playerToken:
      prefer === "host"
        ? undefined
        : prefer === "player"
          ? (player?.token ?? undefined)
          : hostToken
            ? undefined
            : (player?.token ?? undefined),
  };

  return useQuery({
    queryKey: ["board", payload.code, payload.hostToken ?? "", payload.playerToken ?? ""],
    queryFn: async () => {
      await whenPhoneStoreReady();
      const fallback = () => loadBoardCache(upper)?.board ?? cached ?? null;

      const pull = async () => {
        const board = await getBoard({ data: payload });
        saveBoardCache(board);
        rememberSnapshot(snapshotFromBoard(board));
        rememberLastHunt(upper, board.role === "host" ? "host" : "player");
        return board;
      };

      try {
        return await pull();
      } catch (err) {
        const revived = await reviveHunt(upper);
        if (revived) {
          try {
            let restored = await pull();
            if (player?.token) {
              const phone = loadBoardCache(upper);
              for (const photo of phone?.board.yourPhotos ?? []) {
                if (!photo.photoData) continue;
                const oldItem = phone?.board.items.find((item) => item.id === photo.itemId);
                const byTitle = oldItem
                  ? restored.items.find((item) => item.title === oldItem.title)
                  : undefined;
                const byIndex =
                  restored.items[
                    phone?.board.items.findIndex((item) => item.id === photo.itemId) ?? -1
                  ];
                const item = byTitle ?? byIndex;
                if (!item) continue;
                try {
                  await submitPhoto({
                    data: {
                      code: upper,
                      playerToken: player.token,
                      itemId: item.id,
                      photoData: photo.photoData,
                      note: photo.note ?? "",
                    },
                  });
                } catch {
                  // stills stay on this phone even if the live board is mid-restore
                }
              }
              restored = await pull();
            }
            return restored;
          } catch {
            const board = fallback();
            if (board) {
              rememberLastHunt(upper, board.role === "host" ? "host" : "player");
              return board;
            }
          }
        }
        const board = fallback();
        if (board) {
          rememberLastHunt(upper, board.role === "host" ? "host" : "player");
          return board;
        }
        throw err;
      }
    },
    initialData: cached,
    initialDataUpdatedAt: loadBoardCache(upper)?.savedAt,
    placeholderData: (previous) => previous ?? cached,
    refetchInterval: (query) => (query.state.data ? 8000 : false),
    refetchOnWindowFocus: true,
    retry: false,
    throwOnError: false,
    staleTime: 4000,
    gcTime: 24 * 60 * 60 * 1000,
  });
}
