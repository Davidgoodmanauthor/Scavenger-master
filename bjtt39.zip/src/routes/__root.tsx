import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  createRootRoute,
  HeadContent,
  Outlet,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth/provider";
import { ThemeProvider } from "@/lib/theme";
import { THEME_BOOT } from "@/lib/theme-boot";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { JoinHashListener } from "@/components/join-hash";
import { installPhonePersist } from "@/lib/phone-store";
import appCss from "../styles.css?url";

const APP_NAME = "Scavenger Master";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "Host a five-find scavenger hunt for any crew. Players join with a code. The wheel picks the prize.",
      },
      { name: "theme-color", content: "#0c0b08" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Mono:wght@500&display=swap",
      },
    ],
  }),
  component: RootDocument,
});

function RootDocument() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            refetchOnWindowFocus: false,
            staleTime: 1500,
            throwOnError: false,
            retry: 1,
          },
        },
      }),
  );

  useEffect(() => {
    installPhonePersist();
  }, []);

  return (
    <html lang="en" className="night antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body suppressHydrationWarning>
        <script src="/boot.js" />
        <script dangerouslySetInnerHTML={{ __html: THEME_BOOT }} />
        <PreviewHostBridge />
        <QueryClientProvider client={queryClient}>
          <ThemeProvider>
            <AuthProvider>
              <JoinHashListener />
              <Outlet />
              <Toaster
                theme="system"
                position="top-center"
                toastOptions={{
                  className:
                    "!bg-surface !text-fg !border-border !font-[Figtree,ui-sans-serif,sans-serif]",
                }}
              />
            </AuthProvider>
          </ThemeProvider>
        </QueryClientProvider>
        <Scripts />
      </body>
    </html>
  );
}
