import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy, Download, Minus, Plus, RotateCcw, Share2, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { PhotoField } from "@/components/photo-field";
import { PrizeWheel } from "@/components/prize-wheel";
import { Scoreboard } from "@/components/scoreboard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  addHuntItems,
  declareWinner,
  ensureHostHunt,
  exportHunt,
  getSubmissionPhoto,
  importHunt,
  receiveGuestStill,
  receiveGuestStillData,
  registerGuestPlayer,
  resolveWheel,
  setSubmissionStatus,
  spinWheel,
  updateHunt,
} from "@/lib/api";
import { getHostToken, rememberHostToken, rememberLastHunt } from "@/lib/device";
import { envById } from "@/lib/environments";
import { inviteText, inviteWarning, rememberPlayUrl, rememberSnapshot, smsInviteHref, snapshotFromBoard } from "@/lib/invite";
import { parseGuestMessage, pingGrade, pingList, StillAssembler, stillsPollUrl } from "@/lib/inbox";
import { filebinStillUrl, playInviteUrl, stillSlug } from "@/lib/play-link";
import { loadBoardCache, peekCachedHostToken, whenPhoneStoreReady } from "@/lib/phone-store";
import { callOrRevive } from "@/lib/revive";
import type { HuntBoard, HuntItem, ItemDraft, WheelSpin } from "@/lib/types";
import { useBoard } from "@/lib/use-board";

export const Route = createFileRoute("/h/$code/host")({ component: HostPage });

function HostPage() {
  const { code } = Route.useParams();
  const upper = code.toUpperCase();
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [paste, setPaste] = useState("");

  useEffect(() => {
    void whenPhoneStoreReady().then(async () => {
      let next = getHostToken(upper) || peekCachedHostToken(upper);
      if (next) {
        rememberHostToken(upper, next);
        rememberLastHunt(upper, "host");
        setToken(next);
        setReady(true);
        return;
      }
      try {
        const result = await ensureHostHunt({ data: { code: upper } });
        rememberHostToken(upper, result.hostToken);
        rememberLastHunt(upper, "host");
        setToken(result.hostToken);
      } catch {
        setToken(null);
      }
      setReady(true);
    });
  }, [upper]);

  const boardQuery = useBoard(upper, "host");
  const cached = loadBoardCache(upper)?.board;
  const live = token ? boardQuery.data : undefined;
  const board = live ?? (token ? cached : undefined);
  const isHost =
    live?.role === "host" || Boolean(token && board && live === undefined);

  useEffect(() => {
    if (!token || !isHost) return;
    let stop = false;
    const seenKey = `sm.inboxSeen.${upper}`;
    const seen = new Set<string>();
    try {
      const raw = window.sessionStorage.getItem(seenKey);
      if (raw) JSON.parse(raw).forEach((id: string) => seen.add(id));
    } catch {
      // ignore
    }
    const assembler = new StillAssembler();
    async function pull() {
      const ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
      const killer = window.setTimeout(() => ctrl?.abort(), 8000);
      try {
        const res = await fetch(stillsPollUrl(upper), ctrl ? { signal: ctrl.signal } : undefined);
        window.clearTimeout(killer);
        const text = await res.text();
        const lines = text.trim().split("\n").filter(Boolean);
        let added = 0;
        let joined = 0;
        for (const line of lines) {
          let ev: {
            id?: string;
            event?: string;
            message?: string;
            attachment?: { url?: string };
          };
          try {
            ev = JSON.parse(line) as {
              id?: string;
              event?: string;
              message?: string;
              attachment?: { url?: string };
            };
          } catch {
            continue;
          }
          if (ev.event !== "message" || !ev.id) continue;
          const still = parseGuestMessage(
            String(ev.message ?? ""),
            ev.id,
            String(ev.attachment?.url ?? ""),
          );
          if (!still || !token) {
            seen.add(ev.id);
            continue;
          }
          if (still.kind === "part") {
            const photoData = assembler.add(still);
            const startKey = `start:${still.callsign}:${still.itemIndex}`;
            if (!seen.has(startKey)) {
              seen.add(startKey);
              toast.message(still.callsign + " sent a still. Receiving…");
            }
            const doneKey = `done:${still.callsign}:${still.itemIndex}`;
            if (!photoData || seen.has(doneKey)) continue;
            seen.add(doneKey);
            try {
              await receiveGuestStillData({
                data: {
                  code: upper,
                  hostToken: token,
                  callsign: still.callsign,
                  giftCard: still.giftCard,
                  beat: still.beat,
                  itemIndex: still.itemIndex,
                  inBeat: still.inBeat,
                  photoData,
                },
              });
              added += 1;
            } catch {
              seen.delete(doneKey);
            }
            continue;
          }
          if (still.kind === "join") {
            const joinKey = `join:${still.callsign.toLowerCase()}`;
            if (seen.has(joinKey)) continue;
            try {
              await registerGuestPlayer({
                data: {
                  code: upper,
                  hostToken: token,
                  callsign: still.callsign,
                  giftCard: still.giftCard,
                  beat: still.beat,
                },
              });
              seen.add(joinKey);
              seen.add(ev.id);
              joined += 1;
            } catch {
              // player will ping join again
            }
          } else if (still.kind === "ping") {
            const pingKey = `ping:${still.callsign}:${still.itemIndex}`;
            if (seen.has(pingKey)) continue;
            seen.add(pingKey);
            toast.message(still.callsign + " sent a still. Receiving…");
            try {
              await receiveGuestStillData({
                data: {
                  code: upper,
                  hostToken: token,
                  callsign: still.callsign,
                  giftCard: still.giftCard,
                  beat: still.beat,
                  itemIndex: still.itemIndex,
                  inBeat: still.inBeat,
                  photoData:
                    "data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACwAAAAAAQABAAACAkQBADs=",
                },
              });
              added += 1;
            } catch {
              seen.delete(pingKey);
            }
          } else {
            if (seen.has(ev.id)) continue;
            try {
              await receiveGuestStill({
                data: {
                  code: upper,
                  hostToken: token,
                  callsign: still.callsign,
                  giftCard: still.giftCard,
                  beat: still.beat,
                  itemIndex: still.itemIndex,
                  inBeat: still.inBeat,
                  photoUrl: still.photoUrl,
                },
              });
              seen.add(ev.id);
              added += 1;
            } catch {
              // Photo is still landing in the bucket. Try again next poll.
            }
          }
        }
        try {
          window.sessionStorage.setItem(seenKey, JSON.stringify([...seen]));
        } catch {
          // ignore
        }
        if ((added > 0 || joined > 0) && !stop) {
          if (added > 0) {
            toast.success(added === 1 ? "A still came in." : `${added} stills came in.`);
          } else {
            toast.success(joined === 1 ? "A player picked a gift card." : `${joined} gift cards on the wheel.`);
          }
          void boardQuery.refetch();
        }
      } catch {
        window.clearTimeout(killer);
      }
    }
    void pull();
    const id = window.setInterval(() => void pull(), 5000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [token, isHost, upper]);

  useEffect(() => {
    if (!token || !isHost) return;
    const board = boardQuery.data;
    if (!board) return;
    let stop = false;
    async function sweep() {
      if (!token || !boardQuery.data) return;
      const live = boardQuery.data;
      const filled = new Set(live.submissions.map((s) => `${s.playerId}:${s.itemId}`));
      let added = 0;
      for (const player of live.players) {
        for (let i = 0; i < live.items.length; i++) {
          const item = live.items[i];
          if (filled.has(`${player.id}:${item.id}`)) continue;
          try {
            await receiveGuestStill({
              data: {
                code: upper,
                hostToken: token,
                callsign: player.callsign,
                giftCard: player.giftCardPick,
                beat: player.beat,
                itemIndex: i,
                inBeat: "",
                photoUrl: filebinStillUrl(upper, `p-${stillSlug(player.callsign)}-${i}.jpg`),
              },
            });
            added += 1;
          } catch {
            // empty slot
          }
        }
      }
      if (added > 0 && !stop) {
        toast.success(added === 1 ? "A still came in." : `${added} stills came in.`);
        void boardQuery.refetch();
      }
    }
    void sweep();
    const id = window.setInterval(() => void sweep(), 5000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [token, isHost, upper, boardQuery.data?.players.length, boardQuery.data?.submissions.length]);

  function claim(event: React.FormEvent) {
    event.preventDefault();
    const next = paste.trim();
    if (!next) return;
    rememberHostToken(upper, next);
    setToken(next);
    void boardQuery.refetch();
  }

  if (!ready) {
    return (
      <AppShell>
        <p className="text-sm text-muted">Opening Admin…</p>
      </AppShell>
    );
  }

  if (!token || (live && live.role !== "host" && !boardQuery.isFetching && !boardQuery.isPending)) {
    return (
      <AppShell>
        <form
          onSubmit={claim}
          className="rounded-xl border border-border bg-surface p-5"
        >
          <h1 className="font-display text-2xl">Opening Admin for {upper}</h1>
          <p className="mt-2 text-sm text-muted">
            If this is stuck, go back and type the hunt code on the first screen. Do not tap the
            player text. That is their page.
          </p>
          <Input
            className="mt-4"
            value={paste}
            onChange={(e) => setPaste(e.target.value)}
            required
          />
          <Button type="submit" className="mt-3 w-full">
            Unlock
          </Button>
        </form>
      </AppShell>
    );
  }

  if (!board || !isHost) {
    return (
      <AppShell>
        <p className="text-sm text-muted">Opening Admin…</p>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <Tabs defaultValue="admin" onValueChange={() => window.scrollTo(0, 0)}>
        <TabsList>
          <TabsTrigger value="admin">Admin</TabsTrigger>
          <TabsTrigger value="hunt">Hunt</TabsTrigger>
          <TabsTrigger value="scores">Scores</TabsTrigger>
          <TabsTrigger value="pot">Pot</TabsTrigger>
        </TabsList>
        <TabsContent value="admin">
          <AdminTab
            board={board}
            code={upper}
            hostToken={token}
            onChanged={() => void boardQuery.refetch()}
          />
        </TabsContent>
        <TabsContent value="hunt">
          <HuntTab
            board={board}
            code={upper}
            hostToken={token}
            onChanged={() => void boardQuery.refetch()}
          />
        </TabsContent>
        <TabsContent value="scores">
          <ScoresTab
            board={board}
            code={upper}
            hostToken={token}
            onChanged={() => void boardQuery.refetch()}
          />
        </TabsContent>
        <TabsContent value="pot">
          <PotTab board={board} code={upper} hostToken={token} />
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}

function AdminTab({
  board,
  code,
  hostToken,
  onChanged,
}: {
  board: HuntBoard;
  code: string;
  hostToken: string;
  onChanged: () => void;
}) {
  const env = envById(board.hunt.environment);
  const [copied, setCopied] = useState<"code" | "link" | "key" | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [testShot, setTestShot] = useState<string | undefined>();
  const fileRef = useRef<HTMLInputElement>(null);
  const snapshot = snapshotFromBoard(board);
  const [playUrl, setPlayUrl] = useState<string | null>(null);
  const [inviting, setInviting] = useState(false);

  useEffect(() => {
    rememberSnapshot(snapshot);
  }, [snapshot.code]);

  useEffect(() => {
    void freshPlayUrl();
  }, [snapshot.code]);

  async function freshPlayUrl(): Promise<string | null> {
    const url = playInviteUrl(snapshot);
    rememberPlayUrl(code, url);
    setPlayUrl(url);
    return url;
  }

  async function inviteNow() {
    if (inviting) return;
    setInviting(true);
    try {
      const url = await freshPlayUrl();
      if (!url) {
        toast.error("Could not make a player link. Try again.");
        return;
      }
      window.location.href = smsInviteHref(snapshot, url);
    } finally {
      setInviting(false);
    }
  }

  async function copy(kind: "code" | "link" | "key", value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(kind);
      setTimeout(() => setCopied(null), 1400);
    } catch {
      toast.error("Could not copy.");
    }
  }

  async function toggleClose() {
    const next = board.hunt.status === "open" ? "closed" : "open";
    try {
      await callOrRevive(code, () => updateHunt({ data: { code, hostToken, status: next } }));
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update.");
    }
  }

  async function onExport() {
    try {
      const payload = await callOrRevive(code, () => exportHunt({ data: { code, hostToken } }));
      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `scavenger-master-${code}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Export failed.");
    }
  }

  async function onImportFile(file: File | undefined) {
    if (!file) return;
    try {
      const text = await file.text();
      const result = await importHunt({ data: { payload: text } });
      rememberHostToken(result.joinCode, result.hostToken, result.board.hunt.title);
      toast.success(`Imported as ${result.joinCode}.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Import failed.");
    }
  }

  return (
    <div className="grid gap-5">
      <div className="-mx-4 overflow-hidden">
        <img src={env.banner} alt="" className="aspect-[16/9] w-full object-cover" />
      </div>
      <div>
        <Badge tone={board.hunt.status === "open" ? "ok" : "warn"}>
          {board.hunt.status === "open" ? "Open" : "Closed"}
        </Badge>
        <h1 className="mt-2 font-display text-3xl">{env.name}</h1>
        <p className="mt-1 text-sm text-muted">Admin {board.hunt.adminName}</p>
      </div>

      <div className="rounded-xl border border-border bg-surface p-4">
        <div className="text-xs uppercase tracking-wider text-muted">Add players</div>
        <div className="mt-1 font-mono text-3xl tracking-[0.28em]">{code}</div>
        <p className="mt-2 text-sm text-muted">
          Same hunt, any day. Five more next week? Text this again. They join behind. If there is a
          pot, it grows when they pick a gift card. Do not close the hunt and do not start over.
        </p>
        <p className="mt-2 text-sm text-accent">{inviteWarning()}</p>
        {playUrl ? (
          <p className="mt-2 break-all font-mono text-xs text-muted">{playUrl}</p>
        ) : (
          <p className="mt-2 text-sm text-muted">Making the player page…</p>
        )}
        <div className="mt-3 flex flex-wrap gap-2">
          <Button
            className="h-11"
            disabled={inviting}
            onClick={() => void inviteNow()}
            style={{ touchAction: "manipulation" }}
          >
            <Share2 className="size-4" />
            {inviting ? "Making a fresh link…" : "Invite another player"}
          </Button>
          <Button variant="secondary" size="sm" onClick={() => void copy("code", code)}>
            {copied === "code" ? <Check /> : <Copy />}
            Copy code
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={() =>
              void (async () => {
                const url = playUrl && playUrl.includes("catbox.moe") ? playUrl : await freshPlayUrl();
                if (!url) {
                  toast.error("Could not make a player link. Try again.");
                  return;
                }
                await copy("link", inviteText(snapshot, url));
              })()
            }
          >
            {copied === "link" ? <Check /> : <Copy />}
            Copy text
          </Button>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-surface p-4">
        <div className="text-xs uppercase tracking-wider text-muted">Players</div>
        {board.players.length === 0 ? (
          <p className="mt-2 text-sm text-muted">
            Gift cards show here as soon as a player picks one. The wheel on Pot fills at the same time.
          </p>
        ) : (
          <>
            <ul className="mt-3 grid gap-2">
              {board.players.map((player) => (
                <li
                  key={player.id}
                  className="flex items-baseline justify-between gap-3 border-b border-border pb-2 last:border-0 last:pb-0"
                >
                  <span className="font-medium">{player.callsign}</span>
                  <span className="text-sm text-accent">
                    {player.giftCardPick.trim() || "Picking a gift card…"}
                  </span>
                </li>
              ))}
            </ul>
            {board.players.some((p) => p.giftCardPick.trim().length >= 2) ? (
              <div className="mt-4">
                <p className="mb-2 text-xs uppercase tracking-wider text-muted">
                  Wheel so far — full spin is on the Pot tab
                </p>
                <PrizeWheel
                  labels={board.players.map((p) => p.giftCardPick.trim()).filter(Boolean)}
                  spin={null}
                  spinning={false}
                />
              </div>
            ) : null}
          </>
        )}
      </div>

      <div>
        <h2 className="font-display text-xl">Test a still on this phone</h2>
        <p className="mt-1 text-sm text-muted">
          Check the camera. This shot is not graded and never hits the board.
        </p>
        <div className="mt-3">
          <PhotoField preview={testShot} onPick={(data) => setTestShot(data)} />
        </div>
        {testShot ? (
          <Button variant="outline" className="mt-2" onClick={() => setTestShot(undefined)}>
            Discard test
          </Button>
        ) : null}
      </div>

      <div className="grid gap-2">
        <p className="text-sm text-muted">
          Export saves a backup file of this hunt on your phone. Import loads a backup. Neither one
          invites players.
        </p>
        <div className="relative flex flex-wrap gap-2 overflow-hidden">
        <Button variant="secondary" onClick={() => void toggleClose()}>
          {board.hunt.status === "open" ? "Close hunt" : "Reopen hunt"}
        </Button>
        <Button variant="outline" onClick={() => void onExport()}>
          <Download />
          Save backup
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          tabIndex={-1}
          aria-hidden="true"
          className="pointer-events-none absolute h-0 w-0 overflow-hidden opacity-0"
          onChange={(e) => void onImportFile(e.target.files?.[0])}
        />
        <Button variant="outline" onClick={() => fileRef.current?.click()}>
          <Upload />
          Load backup
        </Button>
        <Button
          variant="outline"
          onClick={() => void startNewHunt(code, hostToken, board.hunt.status)()}
        >
          <RotateCcw />
          Start a new hunt
        </Button>
        </div>
      </div>

      <div>
        <button
          type="button"
          className="text-xs uppercase tracking-wider text-muted"
          onClick={() => setRevealed((v) => !v)}
        >
          {revealed ? "Hide admin key" : "Show admin key"}
        </button>
        {revealed ? (
          <div className="mt-2 flex gap-2">
            <Input readOnly value={hostToken} className="font-mono text-xs" />
            <Button variant="outline" onClick={() => void copy("key", hostToken)}>
              {copied === "key" ? <Check /> : <Copy />}
            </Button>
          </div>
        ) : (
          <p className="mt-1 text-xs text-muted">Needed on another phone. We cannot recover it.</p>
        )}
      </div>
    </div>
  );
}

function startNewHunt(code: string, hostToken: string, status: string) {
  return async () => {
    try {
      if (status === "open") {
        await updateHunt({ data: { code, hostToken, status: "closed" } });
      }
    } catch {
      // still leave this hunt
    }
    try {
      window.localStorage.removeItem("sm.wizard.v1");
    } catch {
      // ignore
    }
    window.location.assign("/?fresh=1");
  };
}

function HuntTab({
  board,
  code,
  hostToken,
  onChanged,
}: {
  board: HuntBoard;
  code: string;
  hostToken: string;
  onChanged: () => void;
}) {
  const env = envById(board.hunt.environment);
  const itemKey = board.items.map((item) => item.id).join("|");
  const [items, setItems] = useState<HuntItem[]>(board.items);
  const [draft, setDraft] = useState<ItemDraft[]>(blankList);
  const [releasing, setReleasing] = useState(false);
  const [photo, setPhoto] = useState<{
    photoData: string;
    note: string;
    callsign: string;
    title: string;
    submissionId: string;
  } | null>(null);

  useEffect(() => {
    setItems(board.items);
  }, [itemKey]);

  const lists: { no: number; items: HuntItem[] }[] = [];
  for (const item of items) {
    const no = item.listNo || 1;
    const group = lists.find((row) => row.no === no);
    if (group) group.items.push(item);
    else lists.push({ no, items: [item] });
  }

  const closed = board.hunt.status === "closed";
  const canRelease = !closed && items.length < 100;
  const readyDraft = draft.filter((row) => row.title.trim().length >= 2);

  async function saveItems() {
    try {
      await callOrRevive(code, () =>
        updateHunt({
          data: {
            code,
            hostToken,
            items: items.map((item) => ({ id: item.id, title: item.title, hint: item.hint })),
          },
        }),
      );
      toast.success("List saved.");
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save.");
    }
  }

  async function releaseList() {
    if (readyDraft.length === 0) {
      toast.error("Write at least one find.");
      return;
    }
    setReleasing(true);
    try {
      const result = await callOrRevive(code, () =>
        addHuntItems({
          data: {
            code,
            hostToken,
            items: readyDraft.map((row) => ({
              title: row.title.trim(),
              hint: row.hint.trim(),
            })),
          },
        }),
      );
      toast.success(`List ${result.listNo} is live. ${result.added} more find${result.added === 1 ? "" : "s"}.`);
      pingList(code, [
        ...items.map((item) => item.title),
        ...readyDraft.map((row) => row.title.trim()),
      ]);
      setDraft(blankList());
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not release.");
    } finally {
      setReleasing(false);
    }
  }

  async function openCell(playerId: string, itemId: string) {
    const sub = board.submissions.find((s) => s.playerId === playerId && s.itemId === itemId);
    if (!sub) return;
    try {
      const data = await callOrRevive(code, () =>
        getSubmissionPhoto({
          data: { code, hostToken, submissionId: sub.id },
        }),
      );
      setPhoto({ ...data, submissionId: sub.id });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not load still.");
    }
  }

  async function grade(status: "counted" | "rejected") {
    if (!photo) return;
    try {
      await callOrRevive(code, () =>
        setSubmissionStatus({
          data: { code, hostToken, submissionId: photo.submissionId, status },
        }),
      );
      const sub = board.submissions.find((row) => row.id === photo.submissionId);
      const itemIndex = sub ? board.items.findIndex((item) => item.id === sub.itemId) : 0;
      pingGrade(code, photo.callsign, Math.max(0, itemIndex), status);
      setPhoto(null);
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not grade.");
    }
  }

  return (
    <div className="grid gap-6">
      {env.beatRule ? (
        <p className="rounded-lg border border-accent/30 bg-raised px-3 py-2 text-sm">
          Beat rule: {env.beatRule}
        </p>
      ) : null}
      <div>
        <h2 className="font-display text-xl">Finds</h2>
        <p className="mt-1 text-sm text-muted">
          {items.length} live. One point each when you count it. Release another list of up to
          five anytime until you close the hunt.
        </p>
        {lists.map((list) => (
          <div key={list.no} className="mt-4">
            <div className="text-xs uppercase tracking-wider text-muted">List {list.no}</div>
            <ol className="mt-2 space-y-3">
              {list.items.map((item) => {
                const n = items.findIndex((row) => row.id === item.id) + 1;
                return (
                  <li key={item.id} className="rounded-lg border border-border bg-surface p-3">
                    <div className="font-mono text-xs text-faint">Find {n}</div>
                    <Input
                      className="mt-1"
                      value={item.title}
                      onChange={(e) =>
                        setItems((prev) =>
                          prev.map((it) =>
                            it.id === item.id ? { ...it, title: e.target.value } : it,
                          ),
                        )
                      }
                    />
                  </li>
                );
              })}
            </ol>
          </div>
        ))}
        <Button className="mt-3 w-full" onClick={() => void saveItems()}>
          Save list
        </Button>
      </div>

      {canRelease ? (
        <div>
          <h2 className="font-display text-xl">Release another list</h2>
          <p className="mt-1 text-sm text-muted">
            Up to five more finds. Players see them as soon as you release. You can do this
            again later.
          </p>
          <ol className="mt-3 space-y-3">
            {draft.map((row, i) => (
              <li key={i} className="rounded-lg border border-dashed border-border bg-surface p-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-mono text-xs text-faint">New find {i + 1}</div>
                  {draft.length > 1 ? (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="size-9"
                      aria-label="Remove this find"
                      onClick={() => setDraft((prev) => prev.filter((_, idx) => idx !== i))}
                    >
                      <Minus />
                    </Button>
                  ) : null}
                </div>
                <Input
                  className="mt-1"
                  value={row.title}
                  onChange={(e) =>
                    setDraft((prev) =>
                      prev.map((it, idx) =>
                        idx === i ? { ...it, title: e.target.value } : it,
                      ),
                    )
                  }
                  placeholder="What to find"
                  maxLength={80}
                />
              </li>
            ))}
          </ol>
          {draft.length < 5 ? (
            <Button
              type="button"
              variant="outline"
              className="mt-3 w-full"
              onClick={() => setDraft((prev) => [...prev, { title: "", hint: "" }])}
            >
              <Plus />
              Add a line
            </Button>
          ) : null}
          <Button
            className="mt-3 w-full"
            onClick={() => void releaseList()}
            disabled={releasing || readyDraft.length === 0}
          >
            {releasing
              ? "Releasing…"
              : `Release ${readyDraft.length} find${readyDraft.length === 1 ? "" : "s"}`}
          </Button>
        </div>
      ) : closed ? (
        <p className="text-sm text-muted">Hunt is closed. Reopen it to release another list.</p>
      ) : null}

      <div>
        <h2 className="font-display text-xl">Grade stills</h2>
        <p className="mt-1 text-sm text-muted">Tap a gold mark to open the photo.</p>
        <div className="mt-3">
          <Scoreboard board={board} onCell={openCell} />
        </div>
      </div>
      <Dialog open={!!photo} onOpenChange={(open) => !open && setPhoto(null)}>
        <DialogContent>
          {photo ? (
            <>
              <DialogTitle>{photo.callsign}</DialogTitle>
              <DialogDescription>{photo.title}</DialogDescription>
              <img
                src={photo.photoData}
                alt={photo.title}
                className="mt-3 aspect-[4/3] w-full rounded-md object-cover"
              />
              <div className="mt-4 flex gap-2">
                <Button className="flex-1" onClick={() => void grade("counted")}>
                  Count it
                </Button>
                <Button
                  className="flex-1"
                  variant="destructive"
                  onClick={() => void grade("rejected")}
                >
                  Reject
                </Button>
              </div>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function blankList(): ItemDraft[] {
  return Array.from({ length: 5 }, () => ({ title: "", hint: "" }));
}

function ScoresTab({
  board,
  code,
  hostToken,
  onChanged,
}: {
  board: HuntBoard;
  code: string;
  hostToken: string;
  onChanged: () => void;
}) {
  const [photo, setPhoto] = useState<{
    photoData: string;
    note: string;
    callsign: string;
    title: string;
    submissionId: string;
  } | null>(null);
  const ranked = [...board.players].sort(
    (a, b) => b.points - a.points || a.callsign.localeCompare(b.callsign),
  );
  const leader = ranked[0];
  const declared = board.players.find((p) => p.id === board.hunt.declaredWinnerId);

  async function openCell(playerId: string, itemId: string) {
    const sub = board.submissions.find((s) => s.playerId === playerId && s.itemId === itemId);
    if (!sub) return;
    try {
      const data = await callOrRevive(code, () =>
        getSubmissionPhoto({
          data: { code, hostToken, submissionId: sub.id },
        }),
      );
      setPhoto({ ...data, submissionId: sub.id });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not load still.");
    }
  }

  async function grade(status: "counted" | "rejected") {
    if (!photo) return;
    try {
      await callOrRevive(code, () =>
        setSubmissionStatus({
          data: { code, hostToken, submissionId: photo.submissionId, status },
        }),
      );
      const sub = board.submissions.find((row) => row.id === photo.submissionId);
      const itemIndex = sub ? board.items.findIndex((item) => item.id === sub.itemId) : 0;
      pingGrade(code, photo.callsign, Math.max(0, itemIndex), status);
      setPhoto(null);
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not grade.");
    }
  }

  async function crown() {
    if (!leader) return;
    try {
      await callOrRevive(code, () =>
        declareWinner({ data: { code, hostToken, playerId: leader.id } }),
      );
      toast.success(`${leader.callsign} is the winner.`);
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save winner.");
    }
  }

  return (
    <div className="grid gap-4">
      <div>
        <h2 className="font-display text-xl">Scores</h2>
        <p className="mt-1 text-sm text-muted">
          Grade the leader first. Reject a still and their score drops. When the top list is
          clean, mark the winner.
        </p>
      </div>
      {leader ? (
        <div className="rounded-xl border border-border bg-surface p-4">
          <div className="text-xs uppercase tracking-wider text-muted">Leader</div>
          <div className="font-display text-2xl">
            {leader.callsign} · {leader.points} counted
          </div>
          {leader.pending > 0 ? (
            <p className="mt-1 text-sm text-accent">{leader.pending} still waiting on a grade</p>
          ) : null}
          {ranked[1] ? (
            <p className="mt-1 text-sm text-muted">
              Next is {ranked[1].callsign} with {ranked[1].points}
            </p>
          ) : null}
          {declared ? (
            <p className="mt-2 text-sm text-accent">Winner saved: {declared.callsign}</p>
          ) : (
            <Button className="mt-3 w-full" onClick={() => void crown()} disabled={leader.points < 1}>
              This is the winner
            </Button>
          )}
        </div>
      ) : null}
      <Scoreboard board={board} onCell={openCell} />
      <Dialog open={!!photo} onOpenChange={(open) => !open && setPhoto(null)}>
        <DialogContent>
          {photo ? (
            <>
              <DialogTitle>{photo.callsign}</DialogTitle>
              <DialogDescription>
                {photo.title}
                {photo.note ? ` · ${photo.note}` : ""}
              </DialogDescription>
              <img
                src={photo.photoData}
                alt={photo.title}
                className="mt-3 aspect-[4/3] w-full rounded-md object-cover"
              />
              <div className="mt-4 flex gap-2">
                <Button className="flex-1" onClick={() => void grade("counted")}>
                  Count it
                </Button>
                <Button
                  className="flex-1"
                  variant="destructive"
                  onClick={() => void grade("rejected")}
                >
                  Reject
                </Button>
              </div>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PotTab({
  board,
  code,
  hostToken,
}: {
  board: HuntBoard;
  code: string;
  hostToken: string;
}) {
  const [spinning, setSpinning] = useState(false);
  const [spin, setSpin] = useState<WheelSpin | null>(board.latestSpin);
  const [pick, setPick] = useState(board.latestSpin?.landedGiftCard ?? "");
  const [reveal, setReveal] = useState(false);
  const winner = board.players.find((p) => p.id === board.hunt.declaredWinnerId);
  const slices = board.players.filter((p) => p.giftCardPick.trim().length >= 2);
  const cards = slices.map((p) => p.giftCardPick.trim());

  useEffect(() => {
    setSpin(board.latestSpin);
    setPick(board.latestSpin?.landedGiftCard ?? "");
  }, [board.latestSpin?.id]);

  const pending = spin?.outcome === "pending";

  async function spinNow() {
    setSpinning(true);
    setPick("");
    try {
      const result = await callOrRevive(code, () =>
        spinWheel({ data: { code, hostToken, pool: "all" } }),
      );
      setSpin(result.spin);
      window.setTimeout(() => {
        setSpinning(false);
        setPick(result.giftCardPick);
      }, 5400);
    } catch (err) {
      setSpinning(false);
      toast.error(err instanceof Error ? err.message : "Could not spin.");
    }
  }

  async function act(action: "accept" | "deduct") {
    setSpinning(true);
    try {
      const result = await callOrRevive(code, () =>
        resolveWheel({ data: { code, hostToken, action } }),
      );
      if (action === "accept") {
        setSpin((prev) => (prev ? { ...prev, outcome: "accepted" } : prev));
        setSpinning(false);
        toast.success("Accepted.");
        return;
      }
      if (result.spin) {
        setSpin(result.spin);
        window.setTimeout(() => {
          setSpinning(false);
          setPick(result.giftCardPick);
        }, 5400);
      } else {
        setSpinning(false);
      }
    } catch (err) {
      setSpinning(false);
      toast.error(err instanceof Error ? err.message : "Could not resolve.");
    }
  }

  return (
    <div className="grid gap-5">
      <div>
        <h2 className="font-display text-xl">Pot</h2>
        {board.hunt.potEnabled ? (
          <p className="mt-1 text-sm text-muted">
            ${board.hunt.potRemaining} in the pot. ${board.hunt.potPerPlayer} each. Money stays
            among the group. This app never takes payment.
          </p>
        ) : (
          <p className="mt-1 text-sm text-muted">No prize pot on this hunt.</p>
        )}
      </div>
      {winner ? (
        <div className="rounded-xl border border-border bg-surface p-4">
          {reveal ? (
            <div className="py-8 text-center">
              <div className="text-xs uppercase tracking-[0.22em] text-muted">Winner</div>
              <div className="mt-2 font-display text-4xl">{winner.callsign}</div>
            </div>
          ) : (
            <Button size="lg" className="w-full" onClick={() => setReveal(true)}>
              Reveal winner
            </Button>
          )}
        </div>
      ) : (
        <p className="text-sm text-muted">Mark a winner on Scores first, then reveal them here.</p>
      )}
      <PrizeWheel labels={cards} spin={spin} spinning={spinning} />
      {slices.length > 0 ? (
        <ul className="grid gap-1 text-sm">
          {slices.map((player) => (
            <li key={player.id} className="flex justify-between gap-3 text-muted">
              <span>{player.callsign}</span>
              <span className="text-fg">{player.giftCardPick}</span>
            </li>
          ))}
        </ul>
      ) : null}
      {!pending || spinning ? (
        <Button
          size="lg"
          className="w-full"
          onClick={() => void spinNow()}
          disabled={spinning || cards.length === 0}
        >
          {spinning ? "Spinning…" : "Spin"}
        </Button>
      ) : (
        <div className="grid gap-2">
          <div className="rounded-lg border border-border bg-raised p-4">
            <div className="text-xs uppercase tracking-wider text-muted">Landed on</div>
            <div className="font-display text-2xl">{pick || spin?.landedGiftCard}</div>
            {board.hunt.potEnabled ? (
              <p className="mt-1 text-sm text-muted">
                Accept for ${board.hunt.potRemaining}?
              </p>
            ) : null}
          </div>
          <Button size="lg" onClick={() => void act("accept")}>
            Accept
          </Button>
          <Button variant="outline" size="lg" onClick={() => void act("deduct")}>
            No — deduct $10 and spin again
          </Button>
        </div>
      )}
      <Button
        variant="outline"
        onClick={() => void startNewHunt(code, hostToken, board.hunt.status)()}
      >
        <RotateCcw />
        Start a new hunt
      </Button>
    </div>
  );
}
