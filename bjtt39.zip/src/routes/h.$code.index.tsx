import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { PhotoField } from "@/components/photo-field";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { hydrateHunt, importHunt, joinHunt, submitPhoto } from "@/lib/api";
import { getPlayerSession, rememberHostToken, rememberLastHunt, rememberPlayer } from "@/lib/device";
import { envById, normalizeGiftCard, PLAYER_STORES } from "@/lib/environments";
import { parseJoinHash, peekSnapshot, rememberSnapshot, writeJoinHash } from "@/lib/invite";
import { rememberLocalPhoto, loadBoardCache } from "@/lib/phone-store";
import { callOrRevive } from "@/lib/revive";
import { useBoard } from "@/lib/use-board";

export const Route = createFileRoute("/h/$code/")({ component: PlayerPage });

function PlayerPage() {
  const { code } = Route.useParams();
  const navigate = useNavigate();
  const upper = code.toUpperCase();
  const [phase, setPhase] = useState<"name" | "store">("name");
  const [name, setName] = useState("");
  const [store, setStore] = useState("");
  const [otherStore, setOtherStore] = useState("");
  const [beat, setBeat] = useState("");
  const [joining, setJoining] = useState(false);
  const [hydrating, setHydrating] = useState(false);
  const [hydrateTried, setHydrateTried] = useState(false);
  const importRef = useRef<HTMLInputElement>(null);

  const snapshot = useMemo(() => {
    const fromHash = parseJoinHash();
    if (fromHash?.code === upper && fromHash.snapshot) return fromHash.snapshot;
    return peekSnapshot(upper);
  }, [upper]);

  const boardQuery = useBoard(upper, "player");
  const board = boardQuery.data ?? loadBoardCache(upper)?.board;
  const env = board ? envById(board.hunt.environment) : snapshot ? envById(snapshot.environment) : null;

  useEffect(() => {
    setHydrateTried(false);
    setHydrating(false);
    const session = getPlayerSession(upper);
    if (session?.callsign) setName(session.callsign);
  }, [upper]);

  useEffect(() => {
    if (snapshot) {
      rememberSnapshot(snapshot);
      writeJoinHash(snapshot);
    }
  }, [snapshot]);

  useEffect(() => {
    if (!snapshot || hydrateTried || boardQuery.isFetching || board) return;
    if (!boardQuery.isError && boardQuery.data === undefined) return;
    setHydrateTried(true);
    if (!boardQuery.isError) return;
    setHydrating(true);
    void hydrateHunt({ data: snapshot })
      .then(() => boardQuery.refetch())
      .catch(() => undefined)
      .finally(() => setHydrating(false));
  }, [snapshot, board, boardQuery.isError, boardQuery.data, boardQuery.isFetching, hydrateTried]);

  async function onJoin(event: React.FormEvent) {
    event.preventDefault();
    if (!board) return;
    if (board.hunt.potEnabled && phase === "name") {
      if (name.trim().length < 2) return;
      setPhase("store");
      return;
    }
    if (board.hunt.potEnabled && !normalizeGiftCard(store, otherStore)) {
      toast.error("Pick a gift card, or type a local shop under Other.");
      return;
    }
    setJoining(true);
    try {
      const result = await callOrRevive(upper, () =>
        joinHunt({
          data: {
            code: upper,
            callsign: name,
            giftCard: board.hunt.potEnabled ? normalizeGiftCard(store, otherStore) : "",
            beat: board.hunt.environment === "police" ? beat : "",
          },
        }),
      );
      rememberPlayer(result.joinCode, result.playerToken, result.callsign, board.hunt.title);
      rememberLastHunt(result.joinCode, "player");
      await boardQuery.refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not join.");
    } finally {
      setJoining(false);
    }
  }

  async function onPhoto(itemId: string, photoData: string) {
    rememberLocalPhoto(upper, itemId, photoData);
    const player = getPlayerSession(upper);
    if (!player) {
      toast.success("Saved on this phone.");
      await boardQuery.refetch();
      return;
    }
    try {
      await callOrRevive(upper, () =>
        submitPhoto({
          data: { code: upper, playerToken: player.token, itemId, photoData, note: "" },
        }),
      );
      toast.success("Saved and sent for a grade.");
    } catch {
      toast.success("Saved on this phone.");
    }
    await boardQuery.refetch();
  }

  async function onImportFile(file: File | undefined) {
    if (!file) return;
    try {
      const text = await file.text();
      const result = await importHunt({ data: { payload: text } });
      rememberHostToken(result.joinCode, result.hostToken, result.board.hunt.title);
      toast.success(`Board loaded as ${result.joinCode}.`);
      await navigate({ to: "/h/$code", params: { code: result.joinCode } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Import failed.");
    }
  }

  const waiting =
    boardQuery.isPending ||
    boardQuery.isFetching ||
    hydrating ||
    Boolean(snapshot && !hydrateTried && !board);

  if (!board || !env) {
    if (waiting) {
      return (
        <AppShell>
          <p className="text-sm text-muted">Opening hunt as a guest…</p>
        </AppShell>
      );
    }
    return (
      <AppShell>
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-accent">Player</p>
        <h1 className="mt-2 font-display text-3xl">This phone does not have that hunt yet</h1>
        <p className="mt-2 text-sm text-muted">
          No account needed. Ask the admin for the join code, or import the board file they
          exported. Two phones only live-sync when they share the same hosted game.
        </p>
        <form
          className="mt-6 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const next = name.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
            if (next.length >= 4) {
              void navigate({ to: "/h/$code", params: { code: next } });
            }
          }}
        >
          <Input
            value={name}
            onChange={(e) => setName(e.target.value.toUpperCase())}
            placeholder="Join code"
            maxLength={8}
            className="font-mono tracking-[0.18em]"
            aria-label="Join code"
          />
          <Button type="submit" variant="secondary">
            Open
          </Button>
        </form>
        <input
          ref={importRef}
          type="file"
          accept="application/json"
          className="pointer-events-none absolute h-0 w-0 overflow-hidden opacity-0"
          onChange={(e) => void onImportFile(e.target.files?.[0])}
        />
        <Button variant="outline" className="mt-4 w-full" onClick={() => importRef.current?.click()}>
          Import board
        </Button>
        <Button asChild className="mt-2 w-full" variant="ghost">
          <Link to="/">Back</Link>
        </Button>
      </AppShell>
    );
  }

  const you = board.you;
  const closed = board.hunt.status === "closed";
  const potLabel = board.hunt.potEnabled
    ? `$${board.hunt.potRemaining} in the pot · $${board.hunt.potPerPlayer} each`
    : null;

  if (!you && phase === "name") {
    return (
      <AppShell>
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-accent">
          Player · guest · no account
        </p>
        <h1 className="mt-2 font-display text-3xl">Enter your name.</h1>
        <p className="mt-2 text-sm text-muted">
          You are a player. No X. No Grok login. You will not see Admin tools.
        </p>
        <form onSubmit={onJoin} className="mt-6 grid gap-4">
          <div>
            <Label htmlFor="pname">Your name</Label>
            <Input
              id="pname"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              minLength={2}
              maxLength={24}
              autoFocus
              className="mt-1 h-12"
            />
          </div>
          {board.hunt.environment === "police" ? (
            <div>
              <Label htmlFor="beat">Your beat</Label>
              <Input
                id="beat"
                value={beat}
                onChange={(e) => setBeat(e.target.value)}
                maxLength={24}
                className="mt-1 h-12"
                placeholder="West 4"
              />
              <p className="mt-1 text-xs text-muted">{env.beatRule}</p>
            </div>
          ) : null}
          <Button type="submit" size="lg" disabled={joining || closed || name.trim().length < 2}>
            {closed ? "Hunt closed" : board.hunt.potEnabled ? "Next" : joining ? "Joining…" : "Join hunt"}
          </Button>
        </form>
      </AppShell>
    );
  }

  if (!you) {
    return (
      <AppShell>
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-accent">
          Player · guest · no account
        </p>
        <h1 className="mt-2 font-display text-3xl">If you win, which gift card?</h1>
        <p className="mt-2 text-sm text-muted">
          Money stays among the group. This app never takes payment.
        </p>
        <form onSubmit={onJoin} className="mt-6 grid gap-4">
          <div className="flex flex-wrap gap-2">
            {PLAYER_STORES.map((card) => (
              <button
                key={card}
                type="button"
                onClick={() => setStore(card)}
                className={`rounded-full border px-3 py-2 text-sm ${
                  store === card
                    ? "border-accent bg-accent text-accent-fg"
                    : "border-border bg-raised"
                }`}
              >
                {card}
              </button>
            ))}
          </div>
          {store === "Other" ? (
            <Input
              value={otherStore}
              onChange={(e) => setOtherStore(e.target.value)}
              placeholder="Local shop name"
              maxLength={40}
            />
          ) : null}
          <Button
            type="submit"
            size="lg"
            disabled={joining || closed || !normalizeGiftCard(store, otherStore)}
          >
            {closed ? "Hunt closed" : joining ? "Joining…" : "Join hunt"}
          </Button>
          <button
            type="button"
            className="py-3 text-sm text-muted"
            onClick={() => setPhase("name")}
          >
            Back
          </button>
        </form>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="-mx-4 mb-5">
        <img src={env.banner} alt="" className="aspect-[16/9] w-full object-cover" />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Badge>{closed ? "Closed" : "Live"}</Badge>
        <span className="text-xs uppercase tracking-wider text-muted">{env.name}</span>
      </div>
      <h1 className="mt-2 font-display text-3xl">{you.callsign}</h1>
      <p className="mt-1 text-sm text-muted">
        {board.items.length} find{board.items.length === 1 ? "" : "s"} · 1 point each when
        Admin counts it
      </p>
      {potLabel ? <p className="mt-2 text-sm text-accent">{potLabel}</p> : null}
      {you.giftCardPick ? (
        <p className="text-sm text-muted">If you win: {you.giftCardPick}</p>
      ) : null}
      {board.hunt.environment === "police" ? (
        <p className="mt-2 text-sm text-muted">{env.beatRule}</p>
      ) : null}

      <ol className="mt-6 grid gap-4">
        {board.items.map((item, i) => {
          const mine = board.yourPhotos.find((p) => p.itemId === item.id);
          const tone =
            mine?.status === "counted" ? "ok" : mine?.status === "rejected" ? "warn" : "accent";
          const label =
            mine?.status === "counted"
              ? "Graded in"
              : mine?.status === "rejected"
                ? "Redo"
                : mine
                  ? "Waiting on grade"
                  : null;
          return (
            <li key={item.id} className="rounded-xl border border-border bg-surface p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <div className="font-mono text-xs text-faint">Find {i + 1}</div>
                  <h2 className="font-display text-lg">{item.title}</h2>
                  {item.hint ? <p className="mt-1 text-sm text-muted">{item.hint}</p> : null}
                </div>
                {label ? <Badge tone={tone}>{label}</Badge> : null}
              </div>
              <PhotoField
                preview={mine?.photoData}
                disabled={closed}
                onPick={(data) => onPhoto(item.id, data)}
              />
            </li>
          );
        })}
      </ol>
    </AppShell>
  );
}
