import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/h/$code")({
  component: HuntLayout,
});

function HuntLayout() {
  return <Outlet />;
}
