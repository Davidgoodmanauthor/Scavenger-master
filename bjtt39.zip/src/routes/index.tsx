import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { Check, Copy, Share2 } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createHunt } from "@/lib/api";
import {
  getHostToken,
  getLastHunt,
  listHostedHunts,
  listJoinedHunts,
  rememberHostToken,
  rememberLastHunt,
  clearOldHunts,
} from "@/lib/device";
import { ENVIRONMENTS, envById, type HuntEnvironment } from "@/lib/environments";
import {
  inviteText,
  inviteWarning,
  peekPlayUrl,
  rememberPlayUrl,
  rememberSnapshot,
  smsInviteHref,
  snapshotFromDraft,
} from "@/lib/invite";
import { playInviteUrl } from "@/lib/play-link";
import { saveBoardCache, whenPhoneStoreReady, clearHuntCaches } from "@/lib/phone-store";
import { tapHandlers } from "@/lib/tap";
import { useTheme } from "@/lib/theme";
import type { EnvironmentId, HuntSnapshot, ItemDraft } from "@/lib/types";

const WIZARD_KEY = "sm.wizard.v1";
const ENV_IDS = new Set<string>(ENVIRONMENTS.map((e) => e.id));

type WizardDraft = {
  step: number;
  adminName: string;
  potOn: boolean | null;
  potAmount: string;
  environment: EnvironmentId | "";
  items: ItemDraft[];
};

type SetupSearch = {
  s?: number;
  name?: string;
  theme?: "day" | "night";
  pot?: "yes" | "no";
  amt?: string;
  env?: EnvironmentId;
  join?: string;
  fresh?: boolean;
};

function parseSetupSearch(raw: Record<string, unknown>): SetupSearch {
  const sNum = Number(raw.s);
  const nameRaw =
    typeof raw.n === "string" ? raw.n : typeof raw.name === "string" ? raw.name : undefined;
  const name = nameRaw ? String(nameRaw).slice(0, 24) : undefined;
  const theme = raw.theme === "day" || raw.theme === "night" ? raw.theme : undefined;
  const pot = raw.pot === "yes" || raw.pot === "no" ? raw.pot : undefined;
  const amtRaw = typeof raw.amt === "string" ? raw.amt.replace(/[^\d]/g, "") : "";
  const env =
    typeof raw.env === "string" && ENV_IDS.has(raw.env) ? (raw.env as EnvironmentId) : undefined;
  const join =
    typeof raw.join === "string"
      ? raw.join.replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 8)
      : undefined;
  const out: SetupSearch = {};
  if (Number.isInteger(sNum) && sNum >= 1 && sNum <= 5) out.s = sNum;
  if (name) out.name = name;
  if (theme) out.theme = theme;
  if (pot) out.pot = pot;
  if (amtRaw) out.amt = amtRaw;
  if (env) out.env = env;
  if (join && join.length >= 4) out.join = join;
  if (raw.fresh === "1" || raw.fresh === true) out.fresh = true;
  return out;
}

function qs(parts: SetupSearch): string {
  const p = new URLSearchParams();
  if (parts.s && parts.s > 1) p.set("s", String(parts.s));
  if (parts.name) p.set("n", parts.name);
  if (parts.theme === "day") p.set("theme", "day");
  if (parts.pot) p.set("pot", parts.pot);
  if (parts.amt) p.set("amt", parts.amt);
  if (parts.env) p.set("env", parts.env);
  const s = p.toString();
  return s ? `/?${s}` : "/";
}

function readDraftName(): string {
  if (typeof window === "undefined") return "";
  try {
    const raw = window.localStorage.getItem(WIZARD_KEY);
    if (!raw) return "";
    const draft = JSON.parse(raw) as WizardDraft;
    return String(draft.adminName ?? "").trim().slice(0, 24);
  } catch {
    return "";
  }
}

function writeWizardDraft(patch: Partial<WizardDraft>) {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(WIZARD_KEY);
    const cur = raw ? (JSON.parse(raw) as WizardDraft) : ({} as WizardDraft);
    window.localStorage.setItem(WIZARD_KEY, JSON.stringify({ ...cur, ...patch }));
  } catch {
    // quota
  }
}

function readCachedItems(env: string): ItemDraft[] | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(`sm.items.${env}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ItemDraft[];
    if (Array.isArray(parsed) && parsed.length === 5) return parsed;
  } catch {
    // ignore
  }
  try {
    const raw = window.localStorage.getItem(WIZARD_KEY);
    if (!raw) return null;
    const draft = JSON.parse(raw) as WizardDraft;
    if (draft.environment === env && draft.items?.length === 5) return draft.items;
  } catch {
    // ignore
  }
  return null;
}

function cacheItems(env: string, next: ItemDraft[]) {
  if (typeof window === "undefined" || !env) return;
  try {
    window.sessionStorage.setItem(`sm.items.${env}`, JSON.stringify(next));
  } catch {
    // ignore
  }
  writeWizardDraft({ environment: env as EnvironmentId, items: next, step: 4 });
}

function friendlyError(err: unknown): string {
  const msg = err instanceof Error ? err.message : "";
  if (!msg) return "Could not start the hunt. Try Next again.";
  if (msg.trim().startsWith("[") || msg.trim().startsWith("{")) {
    if (/adminName/i.test(msg)) return "Enter your name again.";
    return "Could not start the hunt. Try Next again.";
  }
  if (/does not exist|column/i.test(msg)) {
    return "Pull down to refresh, then tap Next again.";
  }
  return msg;
}

export const Route = createFileRoute("/")({
  validateSearch: parseSetupSearch,
  beforeLoad: ({ search }) => {
    if (search.join) {
      throw redirect({ to: "/h/$code", params: { code: search.join } });
    }
  },
  component: AdminSetup,
});

function AdminSetup() {
  const search = Route.useSearch();
  const { mode } = useTheme();
  const step = search.s ?? 1;
  const adminName = (search.name ?? "").trim();
  const potOn = search.pot === "yes" ? true : search.pot === "no" ? false : null;
  const theme: "day" | undefined = mode === "day" || search.theme === "day" ? "day" : undefined;

  const [potAmount, setPotAmount] = useState(() => search.amt || "10");
  const [environment, setEnvironment] = useState<EnvironmentId | "">(() => search.env ?? "");
  const [items, setItems] = useState<ItemDraft[]>(() => {
    if (!search.env) return [];
    return readCachedItems(search.env) ?? envById(search.env).items.map((item) => ({ ...item }));
  });
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<HuntSnapshot | null>(null);
  const [playUrl, setPlayUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState<"code" | "link" | null>(null);
  const [joined, setJoined] = useState<{ code: string; title: string; callsign: string }[]>([]);
  const [hosted, setHosted] = useState<{ code: string; title: string }[]>([]);
  const [last, setLast] = useState<{ code: string; role: "host" | "player" } | null>(null);
  const [resuming, setResuming] = useState(false);
  const [resumeCode, setResumeCode] = useState("");
  const creatingRef = useRef(false);

  useEffect(() => {
    if (!created) return;
    const existing = peekPlayUrl(created.code);
    if (existing) {
      setPlayUrl(existing);
      return;
    }
    const url = playInviteUrl(created);
    rememberPlayUrl(created.code, url);
    setPlayUrl(url);
  }, [created?.code]);

  const base: SetupSearch = {
    name: adminName || search.name,
    theme,
    pot: search.pot,
    amt: search.amt || potAmount,
    env: search.env || environment || undefined,
  };

  function href(patch: Partial<SetupSearch> = {}) {
    return qs({ ...base, ...patch });
  }

  useEffect(() => {
    if (!search.env) return;
    setEnvironment(search.env);
    const cached = readCachedItems(search.env);
    if (cached) {
      setItems(cached);
      return;
    }
    setItems(envById(search.env).items.map((item) => ({ ...item })));
  }, [search.env]);

  useEffect(() => {
    if (search.amt) setPotAmount(search.amt);
  }, [search.amt]);

  useEffect(() => {
    void whenPhoneStoreReady().then(() => {
      const nextLast = getLastHunt();
      const nextHosted = listHostedHunts();
      setJoined(listJoinedHunts());
      setHosted(nextHosted);
      setLast(nextLast);
      setResuming(false);
      if (search.s && search.s > 1) return;
      try {
        const raw = window.localStorage.getItem(WIZARD_KEY);
        if (!raw) return;
        const draft = JSON.parse(raw) as WizardDraft;
        if (draft.environment && !search.env) {
          setEnvironment(draft.environment);
          if (draft.items?.length) setItems(draft.items);
        }
        if (draft.potAmount && !search.amt) setPotAmount(draft.potAmount);
      } catch {
        // ignore a broken draft
      }
    });
  }, [search.s, search.env, search.amt, search.fresh, search.join]);

  useEffect(() => {
    if (created) return;
    const storedName = adminName.length >= 2 ? adminName : readDraftName();
    if (step === 1 && storedName.length < 2) return;
    const draft: WizardDraft = {
      step,
      adminName: storedName,
      potOn,
      potAmount,
      environment,
      items,
    };
    try {
      window.localStorage.setItem(WIZARD_KEY, JSON.stringify(draft));
    } catch {
      // quota
    }
  }, [created, step, adminName, potOn, potAmount, environment, items]);

  const env = useMemo(
    () => (environment ? envById(environment) : null),
    [environment],
  );

  async function finish() {
    if (created || creatingRef.current || !environment || !env) return;
    const name = (adminName || readDraftName() || "Admin").trim().slice(0, 24);
    const amount = potOn ? Math.max(1, Math.round(Number(potAmount) || 0)) : 0;
    if (potOn && amount < 1) {
      toast.error("Enter how much each player puts in.");
      return;
    }
    creatingRef.current = true;
    setBusy(true);
    try {
      const result = await createHunt({
        data: {
          adminName: name,
          environment,
          potEnabled: Boolean(potOn),
          potPerPlayer: amount,
          items: items.map((item) => ({ title: item.title.trim(), hint: "" })),
        },
      });
      rememberHostToken(result.joinCode, result.hostToken, "Hunt");
      saveBoardCache(result.board);
      rememberLastHunt(result.joinCode, "host");
      const snap = snapshotFromDraft({
        code: result.joinCode,
        environment,
        adminName: name,
        potEnabled: Boolean(potOn),
        potPerPlayer: amount,
        items,
      });
      rememberSnapshot(snap);
      const url = playInviteUrl(snap);
      rememberPlayUrl(result.joinCode, url);
      window.location.replace(`/h/${result.joinCode}/host`);
      return;
      try {
        window.localStorage.removeItem(WIZARD_KEY);
      } catch {
        // ignore
      }
    } catch (err) {
      creatingRef.current = false;
      toast.error(friendlyError(err));
    } finally {
      setBusy(false);
    }
  }

  async function copyValue(kind: "code" | "link", value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(kind);
      window.setTimeout(() => setCopied(null), 1400);
    } catch {
      toast.error("Could not copy.");
    }
  }

  const goldBtn =
    "mt-6 flex h-14 w-full items-center justify-center rounded-md border-0 bg-accent text-base font-medium text-accent-fg no-underline";
  const choiceBtn = (active: boolean) =>
    `flex min-h-14 items-center justify-center rounded-md border px-3 text-center text-base font-medium no-underline ${
      active ? "border-accent bg-accent text-accent-fg" : "border-border bg-raised text-fg"
    }`;
  const backBtn =
    "flex h-14 items-center justify-center rounded-md border border-border bg-raised text-base font-medium text-fg no-underline";

  if (resuming) {
    return (
      <AppShell>
        <p className="text-sm text-muted">Opening your hunt…</p>
        <p className="mt-2 text-sm text-muted">Closing the preview does not delete it.</p>
      </AppShell>
    );
  }

  return (
    <AppShell>
      {step > 1 ? (
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-accent">
          Admin setup {Math.min(step, 5)} of 5
        </p>
      ) : null}

      {step === 1 ? (
        <form
          className="mt-4 grid gap-2 rounded-xl border border-accent bg-surface p-4"
          onSubmit={(event) => {
            event.preventDefault();
            const code = resumeCode.replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 8);
            if (code.length < 4) {
              toast.error("Type the hunt code from the text you sent them.");
              return;
            }
            rememberLastHunt(code, "host");
            window.location.assign(`/h/${code}/host`);
          }}
        >
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-accent">Your Admin</p>
          <h1 className="font-display text-2xl">Get your hunt back</h1>
          <p className="text-sm text-muted">
            The text is for players. Do not tap that link for yourself. Type the code from that
            text here to open Admin.
          </p>
          <Label htmlFor="resume-code">Hunt code from the text</Label>
          <Input
            id="resume-code"
            value={resumeCode}
            onChange={(e) => setResumeCode(e.target.value.toUpperCase())}
            maxLength={8}
            placeholder="ABC123"
            autoCapitalize="characters"
            autoCorrect="off"
            className="h-14 font-mono text-xl tracking-[0.22em]"
          />
          <button type="submit" className={`${goldBtn} mt-2`}>
            Open Admin
          </button>
        </form>
      ) : null}

      {step === 1 && (last || hosted.length > 0) ? (
        <div className="mt-4 grid gap-3">
          {last ? (
            <a
              href={last.role === "host" ? `/h/${last.code}/host` : `/h/${last.code}`}
              className={`${goldBtn} mt-0 no-underline`}
              style={{ touchAction: "manipulation" }}
            >
              Open hunt {last.code}
            </a>
          ) : null}
          {hosted
            .filter((hunt) => hunt.code !== last?.code)
            .map((hunt) => (
              <a
                key={hunt.code}
                href={`/h/${hunt.code}/host`}
                className="block rounded-xl border border-border bg-surface px-4 py-3 no-underline"
              >
                <div className="text-xs uppercase tracking-wider text-muted">Saved on this phone</div>
                <div className="mt-1 font-mono text-xl tracking-[0.18em]">{hunt.code}</div>
              </a>
            ))}
          <button
            type="button"
            className="text-left text-sm text-muted underline-offset-2"
            style={{ touchAction: "manipulation" }}
            {...tapHandlers(() => {
              clearOldHunts();
              clearHuntCaches();
              window.location.href = "/?fresh=1";
            })}
          >
            Clear old hunts on this phone
          </button>
        </div>
      ) : null}

      {step === 1 ? (
        <Step
          title="Or start a new hunt"
          body="Only do this if you do not already have a code. Enter your name."
        >
          <form action="/" method="get">
            <input type="hidden" name="s" value="2" />
            {theme === "day" ? <input type="hidden" name="theme" value="day" /> : null}
            <Label htmlFor="admin-name">Your name</Label>
            <Input
              id="admin-name"
              name="n"
              defaultValue={adminName}
              maxLength={24}
              placeholder="Your name"
              autoComplete="name"
              enterKeyHint="go"
              className="mt-2 h-12"
              onInput={(e) => {
                const name = (e.target as HTMLInputElement).value.trim();
                try {
                  const raw = window.localStorage.getItem(WIZARD_KEY);
                  const draft = (raw ? JSON.parse(raw) : {}) as Partial<WizardDraft>;
                  window.localStorage.setItem(
                    WIZARD_KEY,
                    JSON.stringify({
                      step: 1,
                      adminName: name,
                      potOn: draft.potOn ?? null,
                      potAmount: draft.potAmount ?? "10",
                      environment: draft.environment ?? "",
                      items: draft.items ?? [],
                    }),
                  );
                } catch {
                  // quota
                }
              }}
            />
            <p className="mt-2 text-sm text-muted">
              Type your name, then tap Next. Or press Go on the keyboard.
            </p>
            <input
              type="submit"
              value="Next: prize pot"
              className={goldBtn}
              style={{ touchAction: "manipulation", WebkitAppearance: "none" }}
            />
          </form>
        </Step>
      ) : null}

      {step === 2 ? (
        <Step
          title="Is there a prize pot?"
          body="Money stays among the group. This app never takes payment."
        >
          <div className="grid grid-cols-2 gap-2">
            <a href={href({ s: 2, pot: "yes" })} className={choiceBtn(potOn === true)}>
              Yes
            </a>
            <a href={href({ s: 3, pot: "no" })} className={choiceBtn(potOn === false)}>
              No
            </a>
          </div>
          {potOn === true ? (
            <form action="/" method="get" className="mt-5">
              <input type="hidden" name="s" value="3" />
              <input type="hidden" name="n" value={adminName} />
              <input type="hidden" name="pot" value="yes" />
              {theme === "day" ? <input type="hidden" name="theme" value="day" /> : null}
              {search.env ? <input type="hidden" name="env" value={search.env} /> : null}
              <Label htmlFor="pot-amt">How much does each player put in?</Label>
              <div className="relative mt-2">
                <span className="absolute top-1/2 left-3 -translate-y-1/2 text-muted">$</span>
                <Input
                  id="pot-amt"
                  name="amt"
                  inputMode="numeric"
                  defaultValue={potAmount}
                  className="h-12 pl-7"
                />
              </div>
              <div className="mt-6 grid grid-cols-2 gap-2">
                <a href={href({ s: 1, pot: undefined })} className={backBtn}>
                  Back
                </a>
                <input
                  type="submit"
                  value="Next: hunt type"
                  className="flex h-14 w-full items-center justify-center rounded-md border-0 bg-accent text-base font-medium text-accent-fg"
                  style={{ touchAction: "manipulation", WebkitAppearance: "none" }}
                />
              </div>
            </form>
          ) : (
            <div className="mt-6 grid grid-cols-2 gap-2">
              <a href={href({ s: 1 })} className={backBtn}>
                Back
              </a>
              {potOn === false ? (
                <a href={href({ s: 3, pot: "no" })} className={`${choiceBtn(true)} mt-0`}>
                  Next: hunt type
                </a>
              ) : (
                <span className="flex h-14 items-center justify-center text-sm text-muted">
                  Pick Yes or No
                </span>
              )}
            </div>
          )}
        </Step>
      ) : null}

      {step === 3 ? (
        <Step
          title="What kind of hunt is this?"
          body="This sets the wording, the five finds, and the banner photo. Police is one option, not the whole product."
        >
          <div className="grid grid-cols-1 gap-2">
            {ENVIRONMENTS.map((option) => (
              <a
                key={option.id}
                href={href({ s: 3, env: option.id })}
                className={`${choiceBtn(environment === option.id)} justify-start px-4`}
              >
                {option.name}
              </a>
            ))}
          </div>
          {env ? (
            <>
              <Banner env={env} />
              <p className="mt-3 text-sm text-muted">{env.blurb}</p>
            </>
          ) : (
            <p className="mt-3 text-sm text-muted">
              Pick Police, Fire and EMS, Office, Warehouse, School or teachers, Family and
              friends, or Other.
            </p>
          )}
          <div className="mt-6 grid grid-cols-2 gap-2">
            <a href={href({ s: 2, env: environment || undefined })} className={backBtn}>
              Back
            </a>
            {environment ? (
              <a href={href({ s: 4, env: environment })} className={`${choiceBtn(true)} mt-0`}>
                Next: five finds
              </a>
            ) : (
              <span className="flex h-14 items-center justify-center text-sm text-muted">
                Pick one first
              </span>
            )}
          </div>
        </Step>
      ) : null}

      {step === 4 && !created ? (
        <Step
          title="The five things to find."
          body="Five lines. Rewrite any of them. Later you can release more lists of up to five from the Hunt tab."
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
            }}
          >
            <ol className="space-y-3">
              {items.map((item, i) => (
                <li key={`find-${i}`}>
                  <Label htmlFor={`find-${i}`}>Find {i + 1}</Label>
                  <Input
                    id={`find-${i}`}
                    value={item.title}
                    onChange={(e) => {
                      const title = e.target.value;
                      setItems((prev) => {
                        const next = prev.map((row, index) =>
                          index === i ? { ...row, title, hint: "" } : row,
                        );
                        if (environment) cacheItems(environment, next);
                        return next;
                      });
                    }}
                    className="mt-1"
                    maxLength={80}
                    autoComplete="off"
                    autoCorrect="off"
                  />
                </li>
              ))}
            </ol>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <a href={href({ s: 3 })} className={backBtn}>
                Back
              </a>
              <button
                type="button"
                className="flex h-14 w-full items-center justify-center rounded-md border-0 bg-accent text-base font-medium text-accent-fg"
                style={{ touchAction: "manipulation", WebkitAppearance: "none" }}
                {...tapHandlers(() => {
                  if (busy) return;
                  if (items.length !== 5 || items.some((item) => item.title.trim().length < 2)) {
                    toast.error("Every find needs a name.");
                    return;
                  }
                  if (environment) cacheItems(environment, items);
                  void finish();
                })}
              >
                {busy ? "Saving…" : "Next: invites"}
              </button>
            </div>
          </form>
        </Step>
      ) : null}

      {created ? (
        <Step
          title="Invite players."
          body="No cap on how many. Text them the link. They tap it, type a name, and they are in."
        >
          {created && env ? (
            <>
              <Banner env={env} />
              <div className="mt-4 rounded-xl border border-border bg-surface p-4">
                <div className="text-xs uppercase tracking-wider text-muted">Join code</div>
                <div className="mt-1 font-mono text-3xl tracking-[0.28em]">{created.code}</div>
                <p className="mt-2 text-sm text-muted">
                  {env.name}
                  {potOn ? ` · $${Number(potAmount)} each. Money stays among the group.` : " · No pot"}
                </p>
                <p className="mt-2 text-sm text-accent">{inviteWarning()}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {playUrl ? (
                    <a
                      href={smsInviteHref(created, playUrl)}
                      className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-accent-fg no-underline"
                      style={{ touchAction: "manipulation" }}
                    >
                      <Share2 className="size-4" />
                      Text message
                    </a>
                  ) : (
                    <button
                      type="button"
                      className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-accent-fg"
                      style={{ touchAction: "manipulation" }}
                      {...tapHandlers(() => {
                        void (async () => {
                          const url = playInviteUrl(created);
                          rememberPlayUrl(created.code, url);
                          setPlayUrl(url);
                          window.location.href = smsInviteHref(created, url);
                        })();
                      })}
                    >
                      <Share2 className="size-4" />
                      Text message
                    </button>
                  )}
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => void copyValue("code", created.code)}
                  >
                    {copied === "code" ? <Check /> : <Copy />}
                    Copy code
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => void copyValue("link", inviteText(created, playUrl))}
                  >
                    {copied === "link" ? <Check /> : <Copy />}
                    Copy text
                  </Button>
                </div>
              </div>
              <a
                href={`/h/${created.code}/host`}
                className={`${goldBtn} no-underline`}
                style={{ touchAction: "manipulation" }}
              >
                Continue to Admin
              </a>
            </>
          ) : (
            <div className="mt-4">
              <p className="text-sm text-muted">{busy ? "Making invites…" : "Could not start the hunt."}</p>
              {!busy ? (
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <a href={href({ s: 4 })} className={backBtn}>
                    Back
                  </a>
                  <button
                    type="button"
                    className={choiceBtn(true)}
                    style={{ touchAction: "manipulation" }}
                    {...tapHandlers(() => void finish())}
                  >
                    Try again
                  </button>
                </div>
              ) : null}
            </div>
          )}
        </Step>
      ) : null}

      {step === 1 ? (
        <div className="mt-10 space-y-4 border-t border-border pt-6">
          {last ? (
            <Link
              to={last.role === "host" ? "/h/$code/host" : "/h/$code"}
              params={{ code: last.code }}
              className="block rounded-xl border border-accent/40 bg-surface px-4 py-4"
            >
              <div className="text-xs uppercase tracking-wider text-accent">Continue on this phone</div>
              <div className="mt-1 font-display text-xl">{last.code}</div>
              <p className="mt-1 text-sm text-muted">
                Saved here. Closing the app does not wipe your hunt.
              </p>
            </Link>
          ) : null}
          <p className="text-xs uppercase tracking-wider text-muted">Already have a code?</p>
          <p className="text-sm text-muted">
            Do not make one up. After these five questions the app gives you a code to text
            your players. This box is only if someone already sent you theirs.
          </p>
          <form className="flex gap-2" action="/" method="get">
            <Input
              name="join"
              placeholder="Code they sent you"
              maxLength={8}
              className="font-mono tracking-[0.18em] uppercase"
              aria-label="Join code from someone else"
              autoCapitalize="characters"
              autoCorrect="off"
            />
            <input
              type="submit"
              value="Open"
              className="h-11 shrink-0 rounded-md border border-border bg-raised px-4 text-sm font-medium text-fg"
              style={{ touchAction: "manipulation", WebkitAppearance: "none" }}
            />
          </form>
          {joined.length > 0 ? (
            <div>
              <p className="mb-2 text-xs uppercase tracking-wider text-muted">Playing on this phone</p>
              <div className="grid gap-2">
                {joined.map((hunt) => (
                  <Link
                    key={hunt.code}
                    to="/h/$code"
                    params={{ code: hunt.code }}
                    className="rounded-lg border border-border bg-surface px-3 py-3 text-sm"
                  >
                    <span className="font-medium">{hunt.callsign}</span>
                    <span className="ml-2 font-mono tracking-[0.18em] text-muted">
                      {hunt.code}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      ) : null}
    </AppShell>
  );
}

function Step({
  title,
  body,
  children,
}: {
  title: string;
  body: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-4">
      <h1 className="font-display text-3xl leading-tight font-medium tracking-tight">{title}</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
      <div className="mt-6">{children}</div>
    </section>
  );
}

function Banner({ env }: { env: HuntEnvironment }) {
  return (
    <div className="mt-4 overflow-hidden rounded-lg border border-border">
      <img src={env.banner} alt="" className="aspect-[16/9] w-full object-cover" />
    </div>
  );
}
